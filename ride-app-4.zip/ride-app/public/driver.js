// RideGo captain (driver) app
RideAuth.start('driver', (token, user) => {
  const { $, esc, icon, money, initial } = UI;
  const socket = io({ auth: { token } });
  socket.on('connect_error', () => { UI.token.set(null); location.reload(); });
  const map = UI.makeMap();
  const demoKey = 'ridego_demo';
  const getDemo = () => { try { return localStorage.getItem(demoKey) !== '0'; } catch { return true; } };

  const S = {
    online: false, loc: { lat: 17.385, lng: 78.4867 }, area: null, today: { total: 0, trips: 0 },
    offer: null, offerLeft: 0, ride: null, rating: 0, rated: false, gps: null,
  };
  const app = $('#app');
  app.innerHTML = `
    <header class="appbar"><div class="logo">${UI.bikeSvg}</div><div class="brand" style="line-height:20px">RideGo<span class="tag">CAPTAIN</span><small>Captain Radar</small></div><div class="grow"></div>
      <span class="status-chip" id="chip"><i></i><span id="chipTx">Offline</span></span><button class="avatar" id="prof" aria-label="Account">${esc(initial(user.name))}</button></header>
    <div class="pill" id="pill"><span class="avatar sm">${UI.bikeSvg.replace('<svg class="ic ', '<svg style="width:16px;height:16px" class="ic ')}</span><span class="nm">${esc(user.name)} • ${esc(user.vehicleNumber || '')}</span><span class="sep"></span>
      <button id="pHist" aria-label="Trips">${icon('list', '', 20)}</button><button id="pOut" class="out" aria-label="Log out">${icon('logout', '', 20)}</button></div>
    <div class="banner" id="banner">You are offline • Go online to receive ride requests</div>
    <div class="fabs" id="fabs"><button class="icon-btn" id="locBtn" aria-label="My location">${icon('locate')}</button></div>
    <div class="maptag hide" id="maptag"></div>
    <section class="sheet" id="sheet"></section>
    <nav class="nav"><div class="nav-in"><button class="on" data-nav="radar">${icon('nav')}Radar</button><button data-nav="trips">${icon('wallet')}Earnings</button><button data-nav="acct">${icon('user')}Account</button></div></nav>`;
  const sheet = $('#sheet');
  new ResizeObserver(() => UI.sheetHeight()).observe(sheet);

  // ---------- map ----------
  const L_ = { me: null, pick: null, drop: null, line: null };
  const clear = k => { if (L_[k]) { map.removeLayer(L_[k]); L_[k] = null; } };
  function drawMe() {
    const ll = [S.loc.lat, S.loc.lng];
    if (!L_.me) L_.me = L.marker(ll, { icon: UI.iconBike(S.online), zIndexOffset: 1000 }).addTo(map); else { L_.me.setLatLng(ll); }
    L_.me.setIcon(UI.iconBike(S.online));
  }
  function drawRide() {
    clear('pick'); clear('drop'); clear('line');
    const r = S.ride; if (!r || r.status === 'completed') return;
    if (r.status !== 'started') L_.pick = L.marker([r.pickup.lat, r.pickup.lng], { icon: UI.iconPickup() }).addTo(map);
    L_.drop = L.marker([r.drop.lat, r.drop.lng], { icon: UI.iconDrop() }).addTo(map);
    const t = r.status === 'started' ? r.drop : r.pickup;
    L_.line = L.polyline([[S.loc.lat, S.loc.lng], [t.lat, t.lng]], { color: '#0A8F3C', weight: 5, dashArray: '2 10', lineCap: 'round' }).addTo(map);
  }
  async function refreshArea() { const p = await UI.placeName(S.loc.lat, S.loc.lng); S.area = p; if (!S.ride && !S.offer) render(); }
  map.on('click', e => {
    if (S.online || S.ride) return;
    S.loc = { lat: e.latlng.lat, lng: e.latlng.lng }; drawMe(); refreshArea();
  });
  function locate() {
    if (!navigator.geolocation) return UI.toast('Location is not available. Tap the map to set where you are.');
    navigator.geolocation.getCurrentPosition(pos => {
      if (!S.online && !S.ride) { S.loc = { lat: pos.coords.latitude, lng: pos.coords.longitude }; drawMe(); refreshArea(); }
      map.setView([pos.coords.latitude, pos.coords.longitude], 16);
    }, () => UI.toast('Could not get your location. Tap the map to set where you are.'), { enableHighAccuracy: true, timeout: 8000 });
  }

  // ---------- moving the bike ----------
  let sim = null;
  function driveTo(t) {
    clearInterval(sim); const s0 = { ...S.loc }; let n = 0;
    if (!getDemo()) return;                       // real GPS drives the position instead
    sim = setInterval(() => {
      n++; S.loc = { lat: s0.lat + (t.lat - s0.lat) * n / 30, lng: s0.lng + (t.lng - s0.lng) * n / 30 };
      drawMe(); socket.emit('driver:location', S.loc); if (L_.line) L_.line.setLatLngs([[S.loc.lat, S.loc.lng], [t.lat, t.lng]]);
      if (n >= 30) clearInterval(sim);
    }, 400);
  }
  function startGps() {
    if (getDemo() || S.gps !== null || !navigator.geolocation) return;
    S.gps = navigator.geolocation.watchPosition(pos => {
      S.loc = { lat: pos.coords.latitude, lng: pos.coords.longitude }; drawMe(); socket.emit('driver:location', S.loc);
      if (S.online && !S.ride) map.panTo([S.loc.lat, S.loc.lng]);
    }, () => {}, { enableHighAccuracy: true, maximumAge: 2000 });
  }
  function stopGps() { if (S.gps !== null) navigator.geolocation.clearWatch(S.gps); S.gps = null; }

  // ---------- online / offline ----------
  function goOnline() { S.online = true; socket.emit('driver:online', { ...S.loc }); startGps(); drawMe(); render(); }
  function goOffline() { S.online = false; socket.emit('driver:offline'); stopGps(); drawMe(); render(); }
  async function loadStats() { try { const st = await UI.api('/api/stats'); S.today = st.today || S.today; if (!S.ride && !S.offer) render(); } catch {} }

  // ---------- screens ----------
  const when = () => new Date().toLocaleString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
  const riderRow = r => { const ri = r.rider || { name: r.riderName }; return `<div class="row" style="gap:12px"><span class="avatar lg">${esc(initial(ri.name))}</span><div class="grow">
      <div class="h-sm">${esc(ri.name || 'Rider')} <span class="badge" style="font-size:11px;padding:2px 8px">Rider</span></div>
      <div class="sub" style="margin:0"><span class="green">${icon('star', 'fill', 14)} <b>${ri.ratingCount ? ri.rating.toFixed(1) : 'New'}</b></span> · ${ri.trips || 0} ride${ri.trips === 1 ? '' : 's'} completed</div></div></div>`; };
  const stops = (r) => `<div class="stops"><div class="st"><span class="cap">Pickup point</span><b>${esc(r.pickupName || 'Pinned location')}</b></div><div class="st drop"><span class="cap grey">Drop location</span><b>${esc(r.dropName || 'Pinned location')}</b></div></div>`;

  function render() {
    $('#chip').classList.toggle('on', S.online); $('#chipTx').textContent = S.online ? 'Online' : 'Offline';
    $('#banner').classList.toggle('hide', S.online || !!S.ride);
    $('#pill').classList.toggle('hide', !!S.ride);
    $('#maptag').classList.add('hide');
    if (S.ride && S.ride.status === 'completed') S.ride.paymentStatus === 'paid' ? paidView() : collectView();
    else if (S.ride) activeView();
    else if (S.offer) offerView();
    else S.online ? onlineView() : offlineView();
    UI.sheetHeight();
  }

  const earnCard = () => `<div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#fff">${icon('wallet')}</span><div><div class="cap grey">TODAY'S EARNINGS</div><div class="h-md num">${money(S.today.total)} <span class="muted" style="font-size:13px;font-weight:600">(${S.today.trips} ride${S.today.trips === 1 ? '' : 's'} completed)</span></div></div></div><button class="link" id="det" style="padding:0">Details ${icon('next', '', 14)}</button></div>`;
  const upiCard = () => `<div class="panel mt12"><div class="row between"><b>Rider direct UPI pay (via QR)</b>${user.upiId ? `<span class="badge green" style="font-size:12px">${icon('checkc', '', 14)} Saved</span>` : '<span class="badge amber" style="font-size:12px">Optional</span>'}</div>
      <div class="row between mt8" style="background:#fff;border-radius:10px;padding:10px 12px"><div class="row">${icon('qr')}<b style="font-family:ui-monospace,Menlo,monospace">${esc(user.upiId || 'No UPI ID added')}</b></div><button class="link" id="editUpi" style="padding:0">${user.upiId ? 'Edit' : 'Add'}</button></div>
      <p class="sub" style="font-size:12px;margin-top:8px">Riders can scan a QR to pay you directly. RideGo never holds your money.</p></div>`;
  function bindCommon() {
    const d = $('#det'); if (d) d.onclick = openTrips;
    const u = $('#editUpi'); if (u) u.onclick = openAcct;
  }

  function offlineView() {
    const a = S.area;
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row"><span class="round-ic" style="width:52px;height:52px">${icon('helmet')}</span><div class="grow"><h1 class="h-md">Captain Control</h1><div class="sub" style="margin:0"><b style="color:#6b7280">● OFFLINE</b>${a ? ' · ' + esc(a.title) : ''}</div></div></div>
      ${earnCard()}${upiCard()}
      <button class="btn primary" id="on">Go online ${icon('zap')}</button>
      <p class="sub" style="text-align:center;margin-top:10px;font-size:13px">Tap anywhere on the map to set where you are.${a && a.subtitle ? ' Ready for rides near ' + esc(a.subtitle) + '.' : ''}</p>`;
    $('#on').onclick = goOnline; bindCommon();
  }
  function onlineView() {
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row between"><span class="badge green"><i style="width:8px;height:8px;border-radius:50%;background:var(--primary-deep);display:inline-block"></i> Online · Waiting for rides</span></div>
      <div class="h-md mt12">You're on the radar</div><p class="sub">Keep this screen open. New ride requests will appear here${S.area ? ' near ' + esc(S.area.title) : ''}.</p>
      ${earnCard()}
      <div class="notice peach">${icon('helmet')}<span>Wear your helmet. Riders must wear one too.</span></div>
      <button class="btn soft" id="off">${icon('power')} Go offline</button>`;
    $('#off').onclick = goOffline; bindCommon();
  }

  // ----- incoming request -----
  let offerTimer = null;
  function showOffer(o) {
    S.offer = o; S.offerLeft = o.seconds; clearInterval(offerTimer); UI.chime(); try { navigator.vibrate && navigator.vibrate([200, 100, 200]); } catch {}
    offerTimer = setInterval(() => { S.offerLeft--; const t = $('#ringTx'); if (t) { t.firstChild.textContent = Math.max(S.offerLeft, 0); $('#ringArc').style.strokeDashoffset = String(125.6 * (1 - Math.max(S.offerLeft, 0) / o.seconds)); const x = $('#exp'); if (x) x.textContent = `Expires in ${Math.max(S.offerLeft, 0)}s`; } if (S.offerLeft <= 0) endOffer(); }, 1000);
    render(); map.fitBounds([[S.loc.lat, S.loc.lng], [o.pickup.lat, o.pickup.lng]], { paddingTopLeft: [40, 110], paddingBottomRight: [40, 520], maxZoom: 16 });
    clear('pick'); L_.pick = L.marker([o.pickup.lat, o.pickup.lng], { icon: UI.iconPickup() }).addTo(map);
  }
  function endOffer() { clearInterval(offerTimer); S.offer = null; clear('pick'); render(); }
  function offerView() {
    const o = S.offer;
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row"><span class="round-ic" style="background:var(--error-bg);color:var(--error);width:44px;height:44px">${icon('zap')}</span><div class="grow"><h1 class="h-md">New Ride Request!</h1><div class="sub" style="margin:0">Respond before the timer ends</div></div>
        <div class="ring"><svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="20" fill="none" stroke="#E5E7EB" stroke-width="5"/><circle id="ringArc" cx="26" cy="26" r="20" fill="none" stroke="#0A8F3C" stroke-width="5" stroke-linecap="round" stroke-dasharray="125.6" style="stroke-dashoffset:${125.6 * (1 - S.offerLeft / o.seconds)};transition:stroke-dashoffset 1s linear"/></svg><div class="tx" id="ringTx">${S.offerLeft}<small>sec</small></div></div></div>
      <div class="panel green row between mt12"><div class="row"><span class="round-ic" style="background:#fff;color:var(--primary-deep)">${icon('checkc')}</span><div><b>Trip fare</b><div class="sub" style="margin:0">Trip: ${o.distanceKm} km · paid by rider</div></div></div><div class="big num green">${money(o.fare)}</div></div>
      <div class="panel mt12"><div class="row between"><span class="row" style="font-weight:700">${icon('nav', '', 18)} Pickup is ${o.pickupDistanceKm} km away</span><span class="badge" style="background:#fff">~${UI.mins(o.pickupDistanceKm)} mins away</span></div><div class="mt12">${stops(o)}</div></div>
      <div class="mt12">${riderRow(o)}</div>
      <div class="notice peach">${icon('helmet')}<span>Ask the rider to wear a helmet before starting.</span></div>
      <div class="btns"><button class="btn soft half" id="rej" style="flex:0.8">${icon('x')} Reject</button><button class="btn primary half" id="acc" style="flex:1.4">${icon('checkc')} Accept ride (${money(o.fare)})</button></div>
      <p class="sub" style="text-align:center;font-size:12px;margin-top:8px" id="exp">Expires in ${S.offerLeft}s</p>`;
    $('#acc').onclick = () => { socket.emit('driver:accept', { rideId: o.id }); clearInterval(offerTimer); S.offer = null; };
    $('#rej').onclick = () => { socket.emit('driver:reject', { rideId: o.id }); endOffer(); };
  }

  // ----- active trip -----
  function activeView() {
    const r = S.ride, idx = { accepted: 0, arrived: 1, started: 2 }[r.status], sc = i => (i < idx ? 'done' : i === idx ? 'now' : '');
    const toDrop = r.status === 'started', target = toDrop ? r.dropName : r.pickupName;
    const btn = { accepted: ['I have arrived', 'checkc'], arrived: ['Start trip', 'next'], started: ['Complete trip', 'checkc'] }[r.status];
    sheet.innerHTML = `<div class="grab"></div>
      <div class="badge green">${icon('zap', '', 14)} ${toDrop ? 'Trip in progress' : r.status === 'arrived' ? 'Waiting for rider' : 'On the way to pickup'} · ${esc(user.vehicleNumber || '')}</div>
      <div class="panel mt12">${riderRow(r)}</div>
      <div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#c8f7d0">${icon('pin')}</span><div><div class="cap grey">HEADING TO</div><div class="h-sm">${esc(toDrop ? 'Drop point' : 'Pickup point')}</div><div class="sub" style="margin:0">${esc(target || 'Pinned location')}</div></div></div><div style="text-align:right"><small class="muted">Fare</small><div class="h-md num">${money(r.fare)}</div></div></div>
      <div class="step3 mt12"><div class="s ${sc(0)}"><div class="d">${UI.bikeSvg}</div>On way to pickup</div><div class="s ${sc(1)}"><div class="d">${icon('pin')}</div>Arrived at pickup</div><div class="s ${sc(2)}"><div class="d">${icon('checkc')}</div>Heading to drop</div></div>
      ${r.status === 'arrived' ? `<div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#fff">${icon('lock')}</span><div><div class="cap grey">START VERIFICATION</div><b>Ask rider for PIN</b></div></div><div class="pin" id="pinBox">${[0, 1, 2, 3].map(i => `<input inputmode="numeric" maxlength="1" data-i="${i}" aria-label="PIN digit ${i + 1}">`).join('')}</div></div>` : ''}
      <div class="notice peach">${icon('helmet')}<span><b>Safety rule:</b> make sure the rider wears a helmet before starting the trip.</span></div>
      <button class="btn primary" id="step">${icon(btn[1])} ${btn[0]}</button>`;
    const pins = [...sheet.querySelectorAll('#pinBox input')];
    pins.forEach((p, i) => { p.oninput = () => { p.value = p.value.replace(/\D/g, '').slice(-1); if (p.value && pins[i + 1]) pins[i + 1].focus(); };
      p.onkeydown = e => { if (e.key === 'Backspace' && !p.value && pins[i - 1]) pins[i - 1].focus(); if (e.key === 'Enter') $('#step').click(); }; });
    if (pins[0]) pins[0].focus();
    $('#step').onclick = () => {
      if (r.status === 'accepted') socket.emit('driver:arrived', { rideId: r.id });
      else if (r.status === 'arrived') { const pin = pins.map(p => p.value).join(''); if (pin.length < 4) return UI.toast('Enter the 4-digit PIN from the rider.'); socket.emit('driver:start', { rideId: r.id, pin }); }
      else socket.emit('driver:complete', { rideId: r.id });
    };
    const t = $('#maptag'); t.classList.remove('hide'); t.innerHTML = `${icon('nav', '', 16)} <b>${toDrop ? 'To drop' : 'To pickup'}</b>`;
  }

  // ----- collect payment -----
  function collectView() {
    const r = S.ride, total = r.total ?? r.fare, qr = r.paymentMethod === 'qr';
    const how = qr ? `<div class="panel mt12" style="background:var(--amber-bg);border:1px solid var(--amber-line)"><div class="row between"><div class="row"><span class="round-ic" style="background:#fff;color:var(--amber)">${icon('qr')}</span><div><b>Rider pays by QR / UPI</b><div class="sub" style="margin:0;font-size:13px">Check your UPI app for a credit of <b>${money(total)}</b></div></div></div><span class="badge amber" style="background:#fff">FAST</span></div>
        <div class="row between mt8" style="background:#fff;border-radius:10px;padding:8px 10px"><div class="row">${icon('wallet', '', 18)}<small class="muted">Your UPI ID:</small><b style="font-family:ui-monospace,Menlo,monospace">${esc(r.upiId || user.upiId || '')}</b></div><button class="link" id="cpy" style="padding:0;font-size:13px">COPY</button></div></div>`
      : r.paymentMethod === 'cash' ? `<div class="panel mt12 row" style="gap:12px">${icon('cash', '', 28)}<div><b>Rider pays in cash</b><div class="sub" style="margin:0;font-size:13px">Collect ${money(total)} in cash from ${esc(r.riderName || 'the rider')}.</div></div></div>`
      : `<div class="notice amber"><span class="spin"></span><span><b>Waiting for the rider to choose how to pay…</b><small>You can confirm as soon as you have the money.</small></span></div>`;
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row between"><span class="badge green">${icon('wallet', '', 16)} Collect payment</span><b class="muted" style="font-size:13px">Trip #${r.id}</b></div>
      <h1 class="h-md mt12" style="font-size:24px">Trip done! Collect <span class="green">${money(total)}</span> from ${esc(r.riderName || 'rider')}</h1>
      ${r.tip ? `<div class="notice ok" style="margin-top:8px">${icon('heart')}<span>Fare ${money(r.fare)} + <b>tip ${money(r.tip)}</b> 🎉 <small>Added by the rider</small></span></div>` : `<p class="sub">Fare ${money(r.fare)} · no tip added yet</p>`}
      ${how}
      <button class="btn primary" id="got">${icon('checkc')} Payment received (${money(total)})</button>
      <button class="btn soft" id="cash">${icon('cash')} Rider paid cash</button>
      <div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#fff">${UI.bikeSvg}</span><b>${esc(user.vehicleNumber || 'Bike')}</b></div><span class="muted" style="font-weight:600">${r.distanceKm} km · ${UI.mins(r.distanceKm)} mins</span></div>`;
    $('#got').onclick = () => socket.emit('driver:payment_received', { rideId: r.id, method: r.paymentMethod || 'cash' });
    $('#cash').onclick = () => socket.emit('driver:payment_received', { rideId: r.id, method: 'cash' });
    const c = $('#cpy'); if (c) c.onclick = () => UI.copyText(r.upiId || user.upiId);
    const t = $('#maptag'); t.classList.remove('hide'); t.innerHTML = `${icon('checkc', '', 16)} <b>Ride completed</b>`;
  }
  function paidView() {
    const r = S.ride, total = r.total ?? r.fare;
    sheet.innerHTML = `<div class="grab"></div>
      <div style="text-align:center"><div class="check-hero">${icon('check')}</div><span class="badge green">${icon('checkc', '', 16)} Payment received</span>
        <div class="big num mt8">${money(total)}</div><div class="sub">${r.paymentMethod === 'qr' ? 'Paid via UPI QR' : 'Paid in cash'}${r.tip ? ' · includes ' + money(r.tip) + ' tip 🎉' : ''}</div></div>
      ${S.rated ? `<div class="notice ok mt12">${icon('checkc')}<span>Thanks for rating ${esc(r.riderName || 'the rider')}.</span></div>` : `<div class="card mt12" style="text-align:center"><h2 class="h-sm">Rate ${esc(r.riderName || 'the rider')}</h2><p class="sub">Ratings help keep RideGo safe and respectful</p>
        <div class="stars">${[1, 2, 3, 4, 5].map(i => `<button data-star="${i}" class="${S.rating >= i ? 'on' : ''}" aria-label="${i} star${i > 1 ? 's' : ''}">${icon('star')}</button>`).join('')}</div>
        <button class="btn primary" id="rate" ${S.rating ? '' : 'disabled'}>Submit rating</button></div>`}
      <button class="btn dark" id="next">${icon('nav')} Back to radar / Next ride</button>`;
    sheet.querySelectorAll('[data-star]').forEach(b => b.onclick = () => { S.rating = +b.dataset.star; paidView(); UI.sheetHeight(); });
    const rt = $('#rate'); if (rt) rt.onclick = () => socket.emit('driver:rate', { rideId: r.id, stars: S.rating }, res => {
      if (res && res.ok) { S.rated = true; paidView(); UI.toast('Thanks for rating!'); } else UI.toast((res && res.error) || 'Could not save rating'); });
    $('#next').onclick = () => { S.ride = null; S.rating = 0; S.rated = false; clear('pick'); clear('drop'); clear('line'); render(); loadStats(); };
    const t = $('#maptag'); t.classList.remove('hide'); t.innerHTML = `<b>Trip completed</b>`;
  }

  // ---------- server events ----------
  socket.on('connect', () => { if (S.online) socket.emit('driver:online', { ...S.loc }); });
  socket.on('driver:offer', showOffer);
  socket.on('driver:offer_expired', () => { if (S.offer) endOffer(); });
  socket.on('driver:error', e => UI.toast(e.message));
  socket.on('driver:cancelled', () => {
    clearInterval(sim); S.ride = null; clear('pick'); clear('drop'); clear('line'); UI.toast('The rider cancelled this ride'); render();
  });
  socket.on('driver:ride', r => {
    const prev = S.ride; S.ride = { ...(prev && prev.id === r.id ? prev : {}), ...r }; S.offer = null; clearInterval(offerTimer);
    if (!prev || prev.status !== r.status) {
      if (r.status === 'accepted') { map.fitBounds([[S.loc.lat, S.loc.lng], [r.pickup.lat, r.pickup.lng]], { paddingTopLeft: [40, 110], paddingBottomRight: [40, 480], maxZoom: 16 }); drawRide(); driveTo(r.pickup); }
      if (r.status === 'started') { drawRide(); driveTo(r.drop); }
      if (r.status === 'completed') { clearInterval(sim); drawRide(); }
      if (r.status === 'arrived') drawRide();
    }
    if (r.status === 'completed' && r.paymentStatus === 'paid' && !(prev && prev.paymentStatus === 'paid')) { UI.celebrate(); S.rated = false; S.rating = 0; loadStats(); }
    render();
  });

  // ---------- chrome ----------
  function openTrips() { Pages.openTrips({ role: 'driver' }); }
  function openAcct() {
    Pages.openAccount({ user, role: 'driver', extra: {
      onUpi: () => render(),
      render: box => {
        box.innerHTML = `<div class="card mt12"><div class="row between"><div><b>Demo driving</b><div class="sub" style="margin:0;font-size:12px">On: the bike moves by itself (for testing on a computer). Off: uses your phone's real GPS.</div></div>
          <label style="display:inline-flex"><input type="checkbox" id="demo" ${getDemo() ? 'checked' : ''} style="width:24px;height:24px;accent-color:var(--primary)"></label></div></div>`;
        box.querySelector('#demo').onchange = e => { try { localStorage.setItem(demoKey, e.target.checked ? '1' : '0'); } catch {} stopGps(); if (S.online) startGps(); UI.toast(e.target.checked ? 'Demo driving on' : 'Using real GPS'); };
      } } });
  }
  $('#locBtn').onclick = locate; $('#pHist').onclick = openTrips; $('#pOut').onclick = () => RideAuth.logout(); $('#prof').onclick = openAcct;
  document.querySelectorAll('.nav button').forEach(b => b.onclick = () => { const k = b.dataset.nav; if (k === 'trips') openTrips(); else if (k === 'acct') openAcct(); });

  drawMe(); render(); loadStats(); locate(); refreshArea();
});
