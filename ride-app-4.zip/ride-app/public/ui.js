// Shared helpers for RideGo screens: icons, API calls, toast, confetti, map markers.
const UI = (() => {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => '₹' + Number(n).toLocaleString('en-IN');
  const initial = n => (String(n || '?').trim()[0] || '?').toUpperCase();

  // ----- icons (simple line icons, 24x24) -----
  const P = {
    back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    next: '<path d="M5 12h14M12 5l7 7-7 7"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    locate: '<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.5"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    checkc: '<circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-6"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    qr: '<path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h3v3h-3zM20 14v3M14 20h3M20 20h1"/>',
    cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>',
    bike: '<circle cx="18.5" cy="17.5" r="3.5"/><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="15" cy="5" r="1"/><path d="M12 17.5V14l-3-3 4-3 2 3h2"/>',
    helmet: '<path d="M3 16a9 9 0 0 1 18 0v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M3 15h10l3-4"/>',
    star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
    zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    power: '<path d="M18.36 6.64a9 9 0 1 1-12.73 0M12 2v10"/>',
    pin: '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
    nav: '<polygon points="3 11 22 2 13 21 11 13 3 11"/>',
    wallet: '<path d="M20 7H5a2 2 0 0 1 0-4h13v4zM3 5v14a2 2 0 0 0 2 2h15V7"/><circle cx="16.5" cy="14" r="1.2"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5"/>',
    help: '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 2.5-3 4M12 17h.01"/>',
    msg: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  };
  const icon = (n, cls = '', size) => `<svg class="ic ${cls}" viewBox="0 0 24 24" ${size ? `style="width:${size}px;height:${size}px"` : ''} aria-hidden="true">${P[n] || ''}</svg>`;
  const bikeSvg = icon('bike');
  const el = html => { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; };

  // ----- talking to the server -----
  const TOKEN_KEY = 'ridego_token';
  const token = { get() { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } },
    set(t) { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch {} } };
  async function api(path, opts = {}) {
    const res = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json', ...(token.get() ? { Authorization: 'Bearer ' + token.get() } : {}) },
      body: opts.body && JSON.stringify(opts.body) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  }
  const placeCache = new Map();
  async function placeName(lat, lng) {
    const k = lat.toFixed(4) + ',' + lng.toFixed(4);
    if (placeCache.has(k)) return placeCache.get(k);
    try { const p = await api(`/api/place?lat=${lat}&lng=${lng}`); placeCache.set(k, p); return p; }
    catch { return { title: 'Pinned location', subtitle: `${lat.toFixed(4)}, ${lng.toFixed(4)}` }; }
  }

  // ----- small feedback helpers -----
  let toastTimer;
  function toast(msg) {
    $$('.toast').forEach(t => t.remove());
    const t = el(`<div class="toast">${esc(msg)}</div>`); document.body.appendChild(t);
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.remove(), 3500);
  }
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); toast('Copied: ' + text); }
    catch { toast(text); }
  }
  function chime() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      [[660, 0], [880, 0.14], [1320, 0.28]].forEach(([f, t]) => {
        const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, ctx.currentTime + t); g.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.35); o.connect(g); g.connect(ctx.destination);
        o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.4);
      });
    } catch {}
  }
  // Confetti from two "cannons" at the bottom corners
  function confetti() {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const cv = document.createElement('canvas'); cv.className = 'confetti'; document.body.appendChild(cv);
    const ctx = cv.getContext('2d'), dpr = window.devicePixelRatio || 1;
    const W = cv.width = innerWidth * dpr, H = cv.height = innerHeight * dpr;
    const colors = ['#0A8F3C', '#89FB99', '#FFC107', '#FF7043', '#111111', '#4FC3F7'];
    const parts = [];
    for (let i = 0; i < 150; i++) {
      const left = i % 2 === 0, dir = left ? 1 : -1;            // left cannon shoots right, right cannon shoots left
      parts.push({ x: left ? 0 : W, y: H, vx: dir * (5 + Math.random() * 11) * dpr, vy: -(20 + Math.random() * 14) * dpr,
        w: (6 + Math.random() * 6) * dpr, h: (4 + Math.random() * 5) * dpr, r: Math.random() * 6, vr: (Math.random() - .5) * .4,
        c: colors[(Math.random() * colors.length) | 0], star: Math.random() < 0.12 });
    }
    const start = performance.now();
    (function frame(now) {
      const t = now - start; ctx.clearRect(0, 0, W, H);
      parts.forEach(p => { p.vy += 0.38 * dpr; p.vx *= 0.992; p.x += p.vx; p.y += p.vy; p.r += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - t / 3200);
        if (p.star) { ctx.font = `${16 * dpr}px sans-serif`; ctx.fillText('★', 0, 0); } else ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore(); });
      if (t < 3200) requestAnimationFrame(frame); else cv.remove();
    })(start);
  }
  function celebrate() { try { navigator.vibrate && navigator.vibrate([40, 40, 80]); } catch {} chime(); confetti(); }

  // ----- map helpers -----
  function makeMap(center = [17.385, 78.4867], zoom = 14) {
    const map = L.map('map', { zoomControl: false, attributionControl: true }).setView(center, zoom);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
    return map;
  }
  const divIcon = (html, size = [42, 42]) => L.divIcon({ html, className: '', iconSize: size, iconAnchor: [size[0] / 2, size[1] / 2] });
  const iconPickup = () => divIcon('<div class="mk mk-pick"></div>', [26, 26]);
  const iconDrop = () => divIcon('<div class="mk mk-drop"></div>', [26, 26]);
  const iconBike = (live = true) => divIcon(`<div class="mk mk-bike ${live ? 'live' : ''}">${bikeSvg}</div>`, [42, 42]);
  const iconWave = () => divIcon('<div class="mk mk-wave"></div>', [200, 200]);
  const label = text => `<span>${esc(text)}</span>`;
  function sheetHeight() {
    const s = document.querySelector('.sheet'); if (!s) return;
    document.documentElement.style.setProperty('--sheet-h', Math.min(s.offsetHeight, innerHeight * 0.6) + 'px');
  }
  function stars(n, total = 5) { return Array.from({ length: total }, (_, i) => icon('star', i < n ? 'fill' : '')).join(''); }
  const ratingText = (avg, cnt) => cnt ? `${avg.toFixed(1)}` : 'New';
  const mins = km => Math.max(1, Math.round(km / 22 * 60)); // rough city speed: 22 km/h

  return { $, $$, esc, money, initial, icon, bikeSvg, el, api, token, placeName, toast, copyText, chime, celebrate, confetti, makeMap, divIcon,
    iconPickup, iconDrop, iconBike, iconWave, label, sheetHeight, stars, ratingText, mins };
})();
