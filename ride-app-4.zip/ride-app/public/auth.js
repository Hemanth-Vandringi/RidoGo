// Login for riders and captains: phone number -> code -> (captain vehicle details).
const RideAuth = (() => {
  const { $, esc, el, icon, api, token } = UI;
  const flag = '<span style="display:inline-block;width:22px;height:15px;border-radius:2px;background:linear-gradient(#FF9933 33%,#fff 33% 66%,#138808 66%);box-shadow:0 0 0 1px #e5e7eb"></span>';
  const fmtPhone = p => `+91 ${p.slice(0, 5)} ${p.slice(5)}`;

  function showLogin(role, done) {
    const isDriver = role === 'driver';
    const ov = el(`<div class="auth"><div class="appbar"><div class="brand"><div class="logo">${UI.bikeSvg}</div>RideGo${isDriver ? '<span class="tag">CAPTAIN</span>' : ''}</div></div><div class="auth-in" id="body"></div></div>`);
    document.body.appendChild(ov);
    const body = $('#body', ov);
    const S = { phone: '', isNew: false, otp: '', name: '', demo: '', vehicles: [], vehicle: 'bike', plate: '', upi: '' };
    let resendAt = 0, timer;

    const setErr = m => { const e = $('#err', ov); if (e) e.textContent = m || ''; };

    function phoneStep() {
      clearInterval(timer);
      body.innerHTML = `
        <div style="text-align:center;margin:22px 0 6px"><span class="badge">${icon('zap', '', 16)} ${isDriver ? 'Drive and earn with RideGo' : 'Fast bike taxis in your city'}</span></div>
        <div class="auth-card">
          <div class="row between"><div><h1 class="h-lg">${isDriver ? 'Driver login' : 'Rider login'}</h1>
            <p class="sub">${isDriver ? 'Enter your phone number to go online' : 'Enter your phone number to get moving'}</p></div>
            <div class="round-ic">${UI.bikeSvg}</div></div>
          <label class="f">Mobile number <span style="color:var(--error)">*</span></label>
          <div class="field"><span class="cc">${flag} +91</span><input id="ph" type="tel" inputmode="numeric" maxlength="10" placeholder="10-digit mobile number" value="${esc(S.phone)}"></div>
          <div class="row mt12">
            <div class="mini"><span class="round-ic" style="width:36px;height:36px;background:var(--peach-bg);color:var(--peach)">${icon('helmet')}</span><div>${isDriver ? 'Helmet for riders' : 'Wear a helmet'}<small>Safety first</small></div></div>
            <div class="mini"><span class="round-ic" style="width:36px;height:36px;background:#c8f7d0">${icon('qr')}</span><div>UPI QR or cash<small>Paid to the captain</small></div></div>
          </div>
          <p class="err-line" id="err"></p>
          <button class="btn primary" id="send">Send code ${icon('next')}</button>
        </div>
        <div class="row mt16" style="color:#6b7280;font-size:12px;font-weight:700;letter-spacing:.6px"><div class="grow" style="height:1px;background:var(--line)"></div>${isDriver ? 'LOOKING FOR A RIDE?' : 'RIDEGO FOR PARTNERS'}<div class="grow" style="height:1px;background:var(--line)"></div></div>
        <div style="text-align:center"><a class="btn ghost" style="display:inline-flex;width:auto;padding:0 20px;border-radius:99px;text-decoration:none;background:#fff" href="${isDriver ? 'rider.html' : 'driver.html'}">${icon('helmet')} ${isDriver ? 'Switch to Rider app' : "I'm a captain"} ${icon('next', '', 16)}</a></div>`;
      const ph = $('#ph', ov); ph.focus();
      const go = async () => {
        setErr(); S.phone = ph.value.replace(/\D/g, '');
        $('#send', ov).disabled = true;
        try {
          const r = await api('/api/otp/request', { method: 'POST', body: { phone: S.phone } });
          S.isNew = r.isNew; S.demo = r.demoOtp || ''; S.otp = ''; resendAt = Date.now() + 30000;
          if (!r.isNew && r.role && r.role !== role) { setErr(`This number is registered as a ${r.role}. Use the ${r.role} app.`); $('#send', ov).disabled = false; return; }
          otpStep();
        } catch (e) { setErr(e.message); $('#send', ov).disabled = false; }
      };
      $('#send', ov).onclick = go; ph.onkeydown = e => e.key === 'Enter' && go();
    }

    function otpStep() {
      body.innerHTML = `
        <div class="hero-ic">${icon('msg')}</div>
        <h1 class="h-md" style="text-align:center">Verify phone number</h1>
        <p class="sub" style="text-align:center">Code sent to ${fmtPhone(S.phone)} <button class="link" id="edit" style="padding:0 4px">Edit ${icon('edit', '', 14)}</button></p>
        ${S.demo ? `<div class="notice amber" style="justify-content:space-between"><span>${icon('help', '', 18)} <b>Demo mode:</b> your code is <b>${esc(S.demo)}</b></span><button class="chip sm" id="fill" style="background:var(--amber-line);color:var(--amber);min-height:30px">${icon('copy', '', 14)} Auto-fill</button></div>` : ''}
        <div class="otp" id="boxes">${Array.from({ length: 6 }, (_, i) => `<input inputmode="numeric" maxlength="1" data-i="${i}" aria-label="Digit ${i + 1}">`).join('')}</div>
        <p class="err-line" id="err" style="text-align:center"></p>
        ${S.isNew ? `<div class="auth-card" style="margin-top:6px"><div class="row between"><b>Your name (first time only)</b><small class="muted">Required</small></div>
          <div class="field mt8" style="background:var(--line-soft)">${icon('user')}<input id="nm" maxlength="40" placeholder="Full name" value="${esc(S.name)}"></div>
          <p class="sub row" style="margin-top:8px;font-size:12px">${icon('lock', '', 14)} ${isDriver ? 'Shown to riders during a trip' : 'Shared with your captain during a trip'}</p></div>` : ''}
        <p class="sub" style="text-align:center;margin-top:16px" id="resend"></p>
        <div style="text-align:center"><button class="link" id="chg" style="color:var(--ink)">Change number</button></div>
        <button class="btn primary" id="ver">${isDriver && S.isNew ? 'Continue' : 'Verify and continue'} ${icon('next')}</button>`;
      const boxes = [...body.querySelectorAll('#boxes input')];
      const read = () => boxes.map(b => b.value).join('');
      boxes.forEach((b, i) => {
        b.oninput = () => { b.value = b.value.replace(/\D/g, '').slice(-1); if (b.value && boxes[i + 1]) boxes[i + 1].focus(); };
        b.onkeydown = e => { if (e.key === 'Backspace' && !b.value && boxes[i - 1]) boxes[i - 1].focus(); if (e.key === 'Enter') $('#ver', ov).click(); };
        b.onpaste = e => { const t = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6); if (t) { e.preventDefault(); t.split('').forEach((c, j) => boxes[j] && (boxes[j].value = c)); boxes[Math.min(t.length, 5)].focus(); } };
      });
      boxes[0].focus();
      const fill = $('#fill', ov); if (fill) fill.onclick = () => S.demo.split('').forEach((c, i) => boxes[i].value = c);
      $('#edit', ov).onclick = $('#chg', ov).onclick = phoneStep;
      const tick = () => { const left = Math.ceil((resendAt - Date.now()) / 1000), r = $('#resend', ov); if (!r) return clearInterval(timer);
        r.innerHTML = left > 0 ? `Didn't receive SMS? <b>Resend code in ${left}s</b>` : `Didn't receive SMS? <button class="link" id="again" style="padding:0">Resend code</button>`;
        const a = $('#again', ov); if (a) a.onclick = async () => { try { const x = await api('/api/otp/request', { method: 'POST', body: { phone: S.phone } }); S.demo = x.demoOtp || ''; resendAt = Date.now() + 30000; otpStep(); } catch (e) { setErr(e.message); } }; };
      clearInterval(timer); tick(); timer = setInterval(tick, 1000);
      $('#ver', ov).onclick = async () => {
        setErr(); S.otp = read(); const nm = $('#nm', ov); if (nm) S.name = nm.value.trim();
        if (S.otp.length < 6) return setErr('Please enter the 6-digit code.');
        if (S.isNew && !S.name) return setErr('Please enter your name.');
        if (isDriver && S.isNew) return detailsStep();
        submit();
      };
    }

    async function detailsStep() {
      try { S.vehicles = (await api('/api/vehicles')).vehicles; } catch { S.vehicles = [{ id: 'bike', label: 'Bike', note: 'Standard 1-passenger commute' }]; }
      S.vehicle = S.vehicles[0].id;
      body.innerHTML = `
        <div class="auth-card"><div class="row between"><span class="badge tint" style="letter-spacing:.5px">${UI.bikeSvg.replace('class="ic ', 'style="width:16px;height:16px" class="ic ')} CAPTAIN PARTNER PROGRAM</span><span class="badge">Step 2 of 2</span></div>
          <h1 class="h-lg mt12">Vehicle details</h1><p class="sub">Riders see your vehicle and number plate during the trip</p></div>
        <div class="auth-card">
          <label class="f" style="margin-top:0">Vehicle category <span style="color:var(--error)">*</span></label>
          <div id="vlist"></div>
          <label class="f">Vehicle number plate <span style="color:var(--error)">*</span></label>
          <div class="field"><span class="cc" style="font-size:12px;color:#6b7280">IND</span><input id="plate" maxlength="14" placeholder="TS09AB1234" style="font-family:ui-monospace,Menlo,monospace;letter-spacing:1px;text-transform:uppercase" value="${esc(S.plate)}"></div>
          <label class="f">UPI ID for QR payments <span style="color:#6b7280;text-transform:none;letter-spacing:0">(optional)</span></label>
          <div class="field">${icon('qr')}<input id="upi" maxlength="60" placeholder="name@okaxis" value="${esc(S.upi)}"></div>
          <div class="panel mt12 row" style="align-items:flex-start;gap:10px">${icon('wallet')}<div><b>Paid directly to you</b><div class="sub" style="font-size:13px">Riders pay your UPI ID by QR, or cash. RideGo does not hold your earnings.</div></div></div>
          <p class="err-line" id="err"></p>
          <button class="btn primary" id="fin">Verify and continue ${icon('next')}</button>
          <div style="text-align:center"><button class="link" id="bk" style="color:var(--ink)">Back</button></div>
        </div>`;
      const list = $('#vlist', ov);
      const draw = () => list.innerHTML = S.vehicles.map(v => `<div class="vehicle ${v.id === S.vehicle ? 'on' : ''}" data-id="${esc(v.id)}" style="margin-top:0;margin-bottom:8px"><div class="vi">${UI.bikeSvg}</div><div class="grow"><b style="font-size:17px">${esc(v.label)} Taxi</b> <span class="badge green" style="padding:2px 8px;font-size:11px">Active</span><div class="sub">${esc(v.note || '')}</div></div></div>`).join('');
      draw(); list.onclick = e => { const c = e.target.closest('.vehicle'); if (c) { S.vehicle = c.dataset.id; draw(); } };
      $('#bk', ov).onclick = otpStep;
      $('#fin', ov).onclick = () => { S.plate = $('#plate', ov).value; S.upi = $('#upi', ov).value; submit(); };
    }

    async function submit() {
      setErr();
      try {
        const r = await api('/api/otp/verify', { method: 'POST', body: { phone: S.phone, otp: S.otp, name: S.name, role, vehicleType: S.vehicle, vehicleNumber: S.plate, upiId: S.upi } });
        token.set(r.token); clearInterval(timer); ov.remove(); done(r.token, r.user);
      } catch (e) {
        setErr(e.message);
        if (/code/i.test(e.message) && !/UPI|plate|vehicle/i.test(e.message)) otpStep(), setErr(e.message);
      }
    }
    phoneStep();
  }

  // Check for an existing login, otherwise show the login screens.
  async function start(role, onReady) {
    if (token.get()) {
      try {
        const { user } = await api('/api/me');
        if (user.role === role) return onReady(token.get(), user);
        token.set(null);
      } catch { token.set(null); }
    }
    showLogin(role, (t, user) => onReady(t, user));
  }
  async function logout() { try { await api('/api/logout', { method: 'POST' }); } catch {} token.set(null); location.reload(); }
  return { start, logout };
})();
