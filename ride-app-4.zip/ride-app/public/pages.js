// Full-screen pages shared by rider and captain apps: "My trips" and "Account".
const Pages = (() => {
  const { $, esc, el, icon, api, money, initial } = UI;
  const when = s => { const d = new Date(String(s).replace(' ', 'T') + 'Z'); return isNaN(d) ? '' : d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false }); };
  const monthName = () => new Date().toLocaleString('en-IN', { month: 'long' });

  function shell(title, onBack) {
    const p = el(`<div class="page"><div class="appbar"><button class="icon-btn flat" id="back" aria-label="Back">${icon('back')}</button><div class="brand">${esc(title)}</div></div><div class="page-in" id="in"></div></div>`);
    document.body.appendChild(p);
    $('#back', p).onclick = () => { p.remove(); onBack && onBack(); };
    return p;
  }

  async function openTrips({ role, onBookAgain }) {
    const isDriver = role === 'driver';
    const p = shell(isDriver ? 'Trips & earnings' : 'My trips');
    const box = $('#in', p); box.innerHTML = '<p class="sub" style="padding:20px 0">Loading…</p>';
    let h;
    try { h = await api('/api/history'); } catch (e) { box.innerHTML = `<p class="err-line">${esc(e.message)}</p>`; return; }
    const rows = h.rides.map(r => {
      const place = (name, lat) => esc(name || (lat != null ? 'Pinned location' : '—'));
      const total = r.fare + (r.tip || 0);
      const ok = r.status === 'completed';
      const tags = [`<span class="badge ${ok ? 'tint' : r.status === 'cancelled' ? 'red' : ''}">${ok ? icon('checkc', '', 14) : ''} ${esc(r.status.replace('_', ' '))}</span>`];
      if (ok) { tags.push(`<span class="badge">${esc(r.payment.split(' · ')[0])}</span>`, `<span class="badge">${esc(r.payment.split(' · ')[1] || '')}</span>`); }
      if (r.tip) tags.push(`<span class="badge amber">${icon('heart', '', 14)} tip ${money(r.tip)}</span>`);
      if (r.rating) tags.push(`<span class="badge">${icon('star', 'fill', 14)} ${r.rating}</span>`);
      const again = !isDriver && ok && r.dropLat != null ? `<button class="link" data-again="${r.id}">${icon('refresh', '', 16)} Book again</button>` : '';
      return `<div class="trip"><div class="row between"><div class="row"><span class="avatar">${esc(initial(r.other || '?'))}</span>
        <div><b style="font-size:16px">${esc(r.other || (isDriver ? 'Rider' : 'No captain'))}</b><div class="sub" style="margin:0;font-size:13px">${esc(r.vehicle)} · ${esc(when(r.date))} · ${r.distanceKm} km</div></div></div>
        <div style="text-align:right"><div class="h-sm num">${money(total)}</div>${r.tip ? `<small class="green" style="font-weight:700">Includes ${money(r.tip)} tip</small>` : `<small class="muted">Standard fare</small>`}</div></div>
        <div class="panel mt12"><div class="stops"><div class="st"><small>Pickup</small><b style="font-size:14px">${place(r.pickup, r.pickupLat)}</b></div><div class="st drop"><small>Drop-off</small><b style="font-size:14px">${place(r.drop, r.dropLat)}</b></div></div></div>
        <div class="tags">${tags.join('')}</div>${again ? `<div style="text-align:right;margin-top:4px">${again}</div>` : ''}</div>`;
    }).join('') || `<div class="trip" style="text-align:center"><p class="sub">No trips yet.</p></div>`;
    box.innerHTML = `
      <div class="overview"><div class="row between"><span class="cap" style="color:#c8f7d0">${icon('list', '', 16)} ACTIVITY OVERVIEW</span><span class="badge" style="background:rgba(0,0,0,.2);color:#fff">${monthName()}</span></div>
        <div class="mt8" style="opacity:.9;font-size:13px">${isDriver ? 'Total earned' : 'Total spent'}</div>
        <div class="big num">${money(h.total)} <small style="font-size:14px;font-weight:600">across ${h.trips} completed trip${h.trips === 1 ? '' : 's'}</small></div>
        <div><span class="chipx">${icon('pin', '', 16)} ${h.km} km</span>${isDriver && h.today ? `<span class="chipx">${icon('wallet', '', 16)} Today ${money(h.today.total)} (${h.today.trips})</span>` : `<span class="chipx">${UI.bikeSvg.replace('<svg class="ic ', '<svg style="width:16px;height:16px" class="ic ')} Bike rides</span>`}</div></div>
      <div class="row between mt16"><h2 class="h-md">Past rides <span class="badge" style="vertical-align:middle">${h.rides.length}</span></h2></div>
      ${rows}
      <button class="btn soft mt16" id="close">${icon('x')} Close</button>`;
    $('#close', p).onclick = () => p.remove();
    box.querySelectorAll('[data-again]').forEach(b => b.onclick = () => {
      const r = h.rides.find(x => x.id === Number(b.dataset.again)); p.remove(); onBookAgain && onBookAgain(r);
    });
  }

  async function openAccount({ user, role, extra }) {
    const isDriver = role === 'driver';
    const p = shell('Account');
    const box = $('#in', p);
    let st = { rating: null, ratingCount: 0, trips: 0 };
    try { st = await api('/api/stats'); } catch {}
    const comp = st.compliments ? Object.entries(st.compliments).filter(([, n]) => n > 0) : [];
    box.innerHTML = `
      <div class="card mt12 row" style="gap:14px"><span class="avatar lg">${esc(initial(user.name))}</span>
        <div class="grow"><div class="h-md">${esc(user.name)}</div><div class="sub">+91 ${esc(user.phone)}</div>
        <div class="tags"><span class="badge tint">${isDriver ? 'Captain' : 'Rider'}</span><span class="badge">${icon('star', 'fill', 14)} ${st.ratingCount ? st.rating.toFixed(1) + ' (' + st.ratingCount + ')' : 'New'}</span><span class="badge">${st.trips} trip${st.trips === 1 ? '' : 's'}</span></div></div></div>
      ${isDriver ? `<div class="card mt12"><div class="cap grey">VEHICLE</div><div class="row mt8"><span class="round-ic">${UI.bikeSvg}</span><div><b>Bike Taxi</b><div class="sub" style="margin:0">${esc(user.vehicleNumber || '')}</div></div></div></div>
        <div class="card mt12"><div class="row between"><div class="cap grey">RIDER DIRECT UPI PAY (VIA QR)</div></div>
          <div class="field mt8">${icon('qr')}<input id="upiIn" maxlength="60" placeholder="name@okaxis" value="${esc(user.upiId || '')}"></div>
          <p class="sub" style="font-size:12px">Riders scan a QR with this UPI ID to pay you directly. Leave empty to accept cash only.</p>
          <p class="err-line" id="upiErr"></p><button class="btn dark" id="upiSave" style="height:44px">Save UPI ID</button></div>
        ${comp.length ? `<div class="card mt12"><div class="cap grey">COMPLIMENTS FROM RIDERS</div><div class="tags">${comp.map(([k, n]) => `<span class="badge tint">${esc(k)} × ${n}</span>`).join('')}</div></div>` : ''}` : ''}
      <div id="extra"></div>
      <button class="btn danger mt16" id="lo">${icon('logout')} Log out</button>`;
    if (isDriver) $('#upiSave', p).onclick = async () => {
      const v = $('#upiIn', p).value.trim().toLowerCase();
      try { await api('/api/upi', { method: 'POST', body: { upiId: v } }); user.upiId = v || null; $('#upiErr', p).textContent = ''; UI.toast(v ? 'UPI ID saved' : 'UPI ID removed'); extra && extra.onUpi && extra.onUpi(user.upiId); }
      catch (e) { $('#upiErr', p).textContent = e.message; }
    };
    if (extra && extra.render) extra.render($('#extra', p));
    $('#lo', p).onclick = () => RideAuth.logout();
    return p;
  }
  return { openTrips, openAccount };
})();
