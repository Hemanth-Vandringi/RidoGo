// RideGo rider app
RideAuth.start('rider', (token, user) => {
  const { $, esc, icon, money, el, initial } = UI;
  const socket = io({ auth: { token } });
  socket.on('connect_error', () => { UI.token.set(null); location.reload(); });
  const map = UI.makeMap();

  const S = {
    phase: 'home',            // home | quote | searching | nodrivers | active | done | paid
    mode: 'drop',             // which point the next map tap sets
    pickup: null, drop: null, pickupPlace: null, dropPlace: null,
    est: null, vehicles: [], vehicle: null, ride: null,
    results: [], searchMsg: '', recent: [], myLoc: null, rating: 0, compliments: [], rated: false,
  };
  const app = $('#app');
  app.innerHTML = `
    <header class="appbar"><div class="brand"><div class="logo">${UI.bikeSvg}</div>RideGo</div><div class="grow"></div>
      <span class="where" id="phaseLbl">Book Ride</span><button class="avatar" id="prof" aria-label="Account">${esc(initial(user.name))}</button></header>
    <div class="pill" id="pill"><span class="avatar sm">${esc(initial(user.name))}</span><span class="nm">${esc(user.name)}</span><span class="sep"></span>
      <button id="pHist" aria-label="My trips">${icon('clock', '', 20)}</button><button id="pOut" class="out" aria-label="Log out">${icon('logout', '', 20)}</button></div>
    <div class="fabs" id="fabs"><button class="icon-btn" id="locBtn" aria-label="My location">${icon('locate')}</button></div>
    <div class="maptag hide" id="maptag"></div>
    <section class="sheet" id="sheet"></section>
    <nav class="nav"><div class="nav-in"><button class="on" data-nav="ride">${UI.bikeSvg}Ride</button><button data-nav="trips">${icon('clock')}Rides</button><button data-nav="acct">${icon('user')}Account</button></div></nav>`;
  const sheet = $('#sheet');
  new ResizeObserver(() => UI.sheetHeight()).observe(sheet);

  // ---------- map layers ----------
  const L_ = { pick: null, drop: null, line: null, bike: null, wave: null };
  const clearLayer = k => { if (L_[k]) { map.removeLayer(L_[k]); L_[k] = null; } };
  function drawMap() {
    clearLayer('pick'); clearLayer('drop'); clearLayer('line');
    if (S.pickup) L_.pick = L.marker([S.pickup.lat, S.pickup.lng], { icon: UI.iconPickup() }).addTo(map);
    if (S.drop) L_.drop = L.marker([S.drop.lat, S.drop.lng], { icon: UI.iconDrop() }).addTo(map);
    if (S.pickup && S.drop) L_.line = L.polyline([[S.pickup.lat, S.pickup.lng], [S.drop.lat, S.drop.lng]], { color: '#0A8F3C', weight: 5, dashArray: '2 10', lineCap: 'round' }).addTo(map);
    const wantWave = S.phase === 'searching' && S.pickup;
    if (wantWave && !L_.wave) L_.wave = L.marker([S.pickup.lat, S.pickup.lng], { icon: UI.iconWave(), interactive: false, zIndexOffset: -500 }).addTo(map);
    if (!wantWave) clearLayer('wave');
  }
  function fit() {
    if (!S.pickup) return;
    const pts = [[S.pickup.lat, S.pickup.lng]]; if (S.drop) pts.push([S.drop.lat, S.drop.lng]);
    if (pts.length === 1) return map.setView(pts[0], Math.max(map.getZoom(), 15));
    const h = Math.min(sheet.offsetHeight, innerHeight * 0.6);
    map.fitBounds(pts, { paddingTopLeft: [40, 110], paddingBottomRight: [40, h + 90], maxZoom: 17 });
  }

  // ---------- places ----------
  const placeLabel = p => p ? (p.title + (p.subtitle ? ', ' + p.subtitle : '')).slice(0, 100) : null;
  async function setPickup(pt, place) {
    S.pickup = pt; S.pickupPlace = place || null; S.mode = 'drop'; drawMap(); render();
    if (!place) { const p = await UI.placeName(pt.lat, pt.lng); if (S.pickup === pt) { S.pickupPlace = p; if (S.phase === 'home' || S.phase === 'quote') render(); } }
  }
  async function setDrop(pt, place) {
    S.drop = pt; S.dropPlace = place || null; S.results = []; S.searchMsg = ''; drawMap(); render(); fit();
    if (!place) { const p = await UI.placeName(pt.lat, pt.lng); if (S.drop === pt) { S.dropPlace = p; if (S.phase === 'home' || S.phase === 'quote') render(); } }
  }
  function locate(setIt = true) {
    if (!navigator.geolocation) return UI.toast('Location is not available. Tap the map to set pickup.');
    navigator.geolocation.getCurrentPosition(pos => {
      S.myLoc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      map.setView([S.myLoc.lat, S.myLoc.lng], 16);
      if (setIt && S.phase === 'home') setPickup({ ...S.myLoc });
    }, () => { if (setIt) UI.toast('Could not get your location. Tap the map to set pickup.'); }, { enableHighAccuracy: true, timeout: 8000 });
  }
  map.on('click', e => {
    if (S.phase !== 'home') return;
    const pt = { lat: e.latlng.lat, lng: e.latlng.lng };
    if (S.mode === 'pickup' || !S.pickup) setPickup(pt); else setDrop(pt);
  });
  async function doSearch(text) {
    text = (text || '').trim();
    if (text.length < 3) { S.searchMsg = 'Type at least 3 letters, then press search.'; S.results = []; return render(); }
    S.searchMsg = 'Searching…'; S.results = []; render();
    try { const r = await UI.api('/api/search?q=' + encodeURIComponent(text)); S.results = r.results; S.searchMsg = r.results.length ? '' : 'No places found. Try another name, or tap the map.'; }
    catch (e) { S.searchMsg = e.message; }
    render(); const q = $('#q'); if (q) { q.value = text; }
  }

  // ---------- labels ----------
  const STATUS = { accepted: 'Captain is on the way', arrived: 'Captain has arrived', started: 'Trip in progress' };
  const vInfo = id => S.vehicles.find(v => v.id === id) || { label: 'Bike', note: '' };
  const when = () => new Date().toLocaleString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
  const stopsHtml = (pk, dp, pkSub, dpSub) => `<div class="stops"><div class="st"><span class="cap">Pickup</span><b>${esc(pk || 'Pinned location')}</b>${pkSub ? `<small>${esc(pkSub)}</small>` : ''}</div>
    <div class="st drop"><span class="cap grey">Drop-off</span><b>${esc(dp || 'Pinned location')}</b>${dpSub ? `<small>${esc(dpSub)}</small>` : ''}</div></div>`;
  const captainRow = (d, extra = '') => `<div class="panel row" style="gap:12px"><span class="avatar lg">${esc(initial(d.name))}</span><div class="grow">
      <div class="h-sm">${esc(d.name)} <span class="green" style="font-size:14px">${icon('star', 'fill', 14)} ${d.ratingCount ? d.rating.toFixed(1) : 'New'}</span></div>
      <div class="sub" style="margin:0">${esc(vInfo(d.vehicleType).label)} Taxi${d.vehicleNumber ? ' · <b style="color:var(--ink);letter-spacing:.5px">' + esc(d.vehicleNumber) + '</b>' : ''}</div>${extra}</div></div>`;

  // ---------- screens ----------
  function render() {
    const lbl = { home: 'Book Ride', quote: 'Select Ride', searching: 'Finding Captain', nodrivers: 'No captains', active: 'Your trip', done: 'Trip completed', paid: 'Paid' }[S.phase];
    $('#phaseLbl').textContent = lbl;
    $('#pill').classList.toggle('hide', S.phase !== 'home');
    $('#maptag').classList.add('hide');
    ({ home: homeView, quote: quoteView, searching: searchingView, nodrivers: noDriversView, active: activeView, done: doneView, paid: paidView })[S.phase]();
    UI.sheetHeight();
  }

  function homeView() {
    const pk = S.pickupPlace, dp = S.dropPlace;
    const recentChips = !S.drop && S.recent.length ? `<div class="cap grey mt12">RECENT</div><div class="chips" style="flex-wrap:nowrap;overflow-x:auto">${S.recent.map((r, i) => `<button class="chip sm" data-recent="${i}" style="white-space:nowrap">${icon('clock', '', 16)} ${esc((r.drop || 'Pinned').split(',')[0].slice(0, 22))}</button>`).join('')}</div>` : '';
    const results = S.results.length ? `<div class="card mt8" style="padding:4px 12px">${S.results.map((r, i) => `<button class="list-row" data-res="${i}" style="width:100%;background:none;border:0;border-bottom:1px solid var(--line-soft);text-align:left;cursor:pointer;align-items:center"><span class="round-ic" style="width:36px;height:36px">${icon('pin', '', 18)}</span><span class="grow"><b style="display:block">${esc(r.title)}</b><small class="muted">${esc(r.subtitle)}</small></span></button>`).join('')}</div>` : '';
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row between"><div><h1 class="h-md">Where to?</h1><p class="sub">Quickest bike taxis near you</p></div><span class="badge tint">${UI.bikeSvg.replace('class="ic ', 'style="width:16px;height:16px" class="ic ')} Bike taxi</span></div>
      <div class="panel mt12"><div class="stops" style="padding-left:30px">
        <div class="st"><div class="row between"><span class="cap">Step 1 · Pickup point</span><button class="link" id="editPick" style="padding:0;font-size:13px">${S.mode === 'pickup' ? 'Tap the map…' : 'Tap to edit'}</button></div>
          ${S.pickup ? `<b>${esc(pk ? pk.title : 'Locating…')}</b><small>${esc(pk ? pk.subtitle : '')}</small>` : `<b class="muted">Set your pickup</b><small>Tap the map or use the location button</small>`}</div>
        <div class="st drop"><div class="row between"><span class="cap grey" style="color:#374151">Step 2 · Drop point</span>${S.drop ? '<button class="link" id="clearDrop" style="padding:0;font-size:13px">Change</button>' : '<small class="muted">Required</small>'}</div>
          ${S.drop ? `<b>${esc(dp ? dp.title : 'Locating…')}</b><small>${esc(dp ? dp.subtitle : '')}</small>`
            : `<div class="field mt8" style="background:#fff"><input id="q" placeholder="Where are you heading?" autocomplete="off"><button class="go" id="doSearch" aria-label="Search">${icon('search')}</button></div>
               <small class="muted" style="display:block;margin-top:6px">${S.searchMsg ? esc(S.searchMsg) : (S.pickup ? 'Search a place and press Enter, or tap the map to drop a pin.' : 'Set your pickup first.')}</small>`}</div></div></div>
      ${results}${recentChips}
      <div class="btns"><button class="btn soft half" id="startOver">${icon('refresh')} Start over</button><button class="btn primary half" id="find" ${S.pickup && S.drop ? '' : 'disabled'}>Find Bike Taxis ${icon('next')}</button></div>
      <div class="notice peach">${icon('helmet')}<span>Wear a helmet. 1 passenger only.</span></div>`;
    $('#editPick').onclick = () => { S.mode = 'pickup'; render(); UI.toast('Tap the map to move your pickup point'); };
    const cd = $('#clearDrop'); if (cd) cd.onclick = () => { S.drop = null; S.dropPlace = null; drawMap(); render(); };
    const q = $('#q'); if (q) { q.onkeydown = e => e.key === 'Enter' && doSearch(q.value); $('#doSearch').onclick = () => doSearch(q.value); if (S.searchMsg === 'Searching…') q.disabled = true; }
    sheet.querySelectorAll('[data-res]').forEach(b => b.onclick = () => { const r = S.results[+b.dataset.res]; setDrop({ lat: r.lat, lng: r.lng }, { title: r.title, subtitle: r.subtitle }); });
    sheet.querySelectorAll('[data-recent]').forEach(b => b.onclick = () => { const r = S.recent[+b.dataset.recent]; setDrop({ lat: r.dropLat, lng: r.dropLng }, splitName(r.drop)); });
    $('#startOver').onclick = fullReset;
    $('#find').onclick = goQuote;
  }
  const splitName = n => { const [t, ...rest] = String(n || 'Pinned location').split(', '); return { title: t, subtitle: rest.join(', ') }; };

  function goQuote() {
    socket.emit('rider:estimate', { pickup: S.pickup, drop: S.drop }, est => {
      S.est = est; if (!S.vehicles.find(v => v.id === S.vehicle)) S.vehicle = S.vehicles[0] && S.vehicles[0].id;
      S.phase = 'quote'; drawMap(); render(); fit();
    });
  }
  function quoteView() {
    const e = S.est, pk = S.pickupPlace, dp = S.dropPlace;
    const tag = $('#maptag'); tag.classList.remove('hide'); tag.innerHTML = `<b>${esc(pk ? pk.title : 'Pickup')}</b> → <b>${esc(dp ? dp.title : 'Drop')}</b>`;
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row"><button class="icon-btn flat" id="qBack" aria-label="Back">${icon('back')}</button><h1 class="h-md">Select ride</h1></div>
      <div class="panel row between mt8"><div class="row"><span class="round-ic" style="background:#fff">${icon('cash')}</span><div><b style="font-size:16px">Distance: ${e.distanceKm} km</b><div class="sub" style="margin:0">Pay by cash or UPI QR</div></div></div><span class="badge" style="background:#fff">${icon('clock', '', 14)} ~${UI.mins(e.distanceKm)} mins</span></div>
      ${S.vehicles.map(v => `<div class="vehicle ${v.id === S.vehicle ? 'on' : ''}" data-v="${esc(v.id)}"><div class="vi">${UI.bikeSvg}</div>${v.id === S.vehicle ? `<span class="tick">${icon('check')}</span>` : ''}
        <div class="grow"><b style="font-size:18px">${esc(v.label)}</b> <span class="badge green" style="padding:2px 8px;font-size:11px">${UI.mins(e.distanceKm)} min trip</span><div class="sub" style="margin:0">${esc(v.note)}</div><small class="muted">${money(v.base)} base + ${money(v.perKm)}/km</small></div>
        <div><div class="fare">${money(e.fares[v.id])}</div><small class="green" style="font-weight:700;display:block;text-align:right">Fixed fare</small></div></div>`).join('')}
      <div class="notice peach">${icon('helmet')}<span class="grow">${esc(vInfo(S.vehicle).note || 'Wear a helmet.')}</span><span class="badge" style="background:#fbd8c4;color:var(--peach)">Mandatory</span></div>
      <button class="btn primary" id="req">${UI.bikeSvg} Request ${esc(vInfo(S.vehicle).label.toLowerCase())} · ${money(e.fares[S.vehicle])}</button>
      <button class="btn soft" id="startOver">${icon('refresh')} Start over</button>`;
    $('#qBack').onclick = () => { S.phase = 'home'; render(); };
    sheet.querySelectorAll('[data-v]').forEach(c => c.onclick = () => { S.vehicle = c.dataset.v; render(); });
    $('#startOver').onclick = fullReset;
    $('#req').onclick = requestRide;
  }

  function requestRide() {
    $('#req').disabled = true;
    socket.emit('rider:request', { pickup: S.pickup, drop: S.drop, vehicleType: S.vehicle, pickupName: placeLabel(S.pickupPlace), dropName: placeLabel(S.dropPlace) }, r => {
      if (r.error) { UI.toast(r.error); return render(); }
      S.ride = { id: r.rideId, status: 'searching', fare: S.est.fares[S.vehicle], distanceKm: S.est.distanceKm, vehicleType: S.vehicle, pickupName: placeLabel(S.pickupPlace), dropName: placeLabel(S.dropPlace) };
      S.phase = 'searching'; S.rated = false; S.rating = 0; S.compliments = []; drawMap(); render();
    });
  }

  function searchingView() {
    const r = S.ride, pk = S.pickupPlace, v = vInfo(r.vehicleType);
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row"><div class="grow"><h1 class="h-md"><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:var(--primary);margin-right:8px"></span>Finding a driver…</h1><p class="sub">Searching bike taxis near ${esc(pk ? pk.title : 'your pickup')}</p></div><span class="round-ic" style="border:2px solid var(--primary);width:52px;height:52px">${UI.bikeSvg}</span></div>
      <div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#fff;width:52px;height:52px">${UI.bikeSvg}</span><div><div class="h-md num">${money(r.fare)} <span class="muted" style="font-size:15px;font-weight:600">· ${r.distanceKm} km</span></div><div class="sub" style="margin:0">${esc(v.label)} Taxi</div></div></div></div>
      <div class="notice amber">${icon('helmet')}<span>Wear a helmet. 1 passenger only.</span></div>
      <div class="card mt12">${stopsHtml(r.pickupName, r.dropName)}</div>
      <button class="btn danger" id="cancel">${icon('x')} Cancel ride</button>
      <p class="sub row" style="justify-content:center;margin-top:10px;font-size:12px">${icon('lock', '', 14)} Free cancellation until your trip starts</p>`;
    $('#cancel').onclick = () => socket.emit('rider:cancel', { rideId: r.id });
  }
  function noDriversView() {
    sheet.innerHTML = `<div class="grab"></div><div class="check-hero" style="background:var(--amber-bg);color:var(--amber)">${UI.bikeSvg}</div>
      <h1 class="h-md" style="text-align:center">No captains nearby</h1><p class="sub" style="text-align:center">All bike captains close to you are busy or offline right now. Please try again in a moment.</p>
      <button class="btn primary" id="again">${icon('refresh')} Try again</button><button class="btn soft" id="home">Back</button>`;
    $('#again').onclick = () => { S.phase = 'quote'; render(); };
    $('#home').onclick = () => { S.phase = 'home'; render(); };
  }

  function activeView() {
    const r = S.ride, d = r.driver || { name: 'Captain' };
    const idx = { accepted: 0, arrived: 1, started: 2 }[r.status];
    const sc = i => (i < idx ? 'done' : i === idx ? 'now' : '');
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row between"><span class="badge green">${icon('zap', '', 14)} ${esc(STATUS[r.status])}</span><small class="muted num">${money(r.fare)} · ${r.distanceKm} km</small></div>
      <div class="mt12">${captainRow(d)}</div>
      <div class="step3 mt12"><div class="s ${sc(0)}"><div class="d">${UI.bikeSvg}</div>On the way</div><div class="s ${sc(1)}"><div class="d">${icon('pin')}</div>Arrived</div><div class="s ${sc(2)}"><div class="d">${icon('checkc')}</div>Trip started</div></div>
      ${r.status !== 'started' && r.pin ? `<div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#fff">${icon('lock')}</span><div><b>Start PIN</b><div class="sub" style="margin:0;font-size:12px">Tell your captain this PIN to start</div></div></div><div class="pin">${r.pin.split('').map(c => `<span>${c}</span>`).join('')}</div></div>` : ''}
      <div class="card mt12">${stopsHtml(r.pickupName, r.dropName)}</div>
      ${r.status !== 'started' ? `<button class="btn danger" id="cancel">${icon('x')} Cancel ride</button>` : `<div class="notice ok">${icon('shield')}<span>Enjoy your ride. Wear your helmet.</span></div>`}`;
    const c = $('#cancel'); if (c) c.onclick = () => socket.emit('rider:cancel', { rideId: r.id });
    const t = $('#maptag'); t.classList.remove('hide'); t.innerHTML = r.status === 'started' ? `Heading to <b>${esc((r.dropName || 'drop-off').split(',')[0])}</b>` : `Pickup: <b>${esc((r.pickupName || 'your location').split(',')[0])}</b>`;
  }

  // ----- completed trip: tip + payment -----
  const TIPS = [0, 5, 10, 20, 30, 40, 50];
  function tipBlock(r) {
    return `<div class="row" style="margin-top:16px;gap:8px">${icon('heart', '', 20)}<b class="grow" style="font-size:16px">Add a tip for your captain?</b><span class="muted">(optional)</span></div>
      <div class="chips" style="flex-wrap:nowrap;overflow-x:auto;margin-bottom:4px">${TIPS.map(t => `<button class="chip ${(r.tip || 0) === t ? 'on' : ''}" data-tip="${t}" style="white-space:nowrap">${(r.tip || 0) === t ? icon('check') : ''}${t === 0 ? 'No tip' : money(t)}</button>`).join('')}</div>
      <p class="sub row" style="font-size:12px;gap:6px">${icon('shield', '', 14)} 100% of the tip goes straight to ${esc((r.driver || {}).name || 'your captain')}</p>`;
  }
  function doneView() {
    const r = S.ride, d = r.driver || { name: 'Captain' }, total = r.total ?? r.fare, qr = r.paymentMethod === 'qr';
    const breakdown = r.tip ? `Fare ${money(r.fare)} + tip ${money(r.tip)}` : `Trip fare ${money(r.fare)}`;
    let payPart;
    if (qr && r.payQr) {
      payPart = `<div style="text-align:center;margin-top:14px"><span class="badge green">${icon('qr', '', 16)} UPI direct payment</span>
        <p class="sub" style="margin-top:8px">Scan with any UPI app (GPay, PhonePe, Paytm) to pay <b class="green">${money(total)}</b> directly to your captain</p></div>
        <div class="qr-card mt8"><img src="${r.payQr}" alt="UPI QR code"><div class="h-md num mt8">${money(total)}</div><span class="badge" style="background:var(--primary-tint);color:var(--primary-deep)">${esc(breakdown)}</span></div>
        <div class="panel row between mt12"><div class="row"><span class="round-ic" style="background:#fff">${UI.bikeSvg}</span><div><b>${esc(d.name)}</b><div class="sub" style="margin:0;font-family:ui-monospace,Menlo,monospace">${esc(r.upiId || '')}</div></div></div><button class="chip sm" id="copyUpi" style="background:#fff">${icon('copy', '', 16)} Copy</button></div>
        <a class="btn dark" href="${esc(r.payUri)}" style="text-decoration:none">${icon('qr')} Open my UPI app</a>
        <div class="notice amber"><span class="spin"></span><span><b>Waiting for the captain to confirm payment…</b><small>Keep this screen open while ${esc(d.name)} checks the UPI alert.</small></span></div>
        <button class="btn soft" id="payCash">${icon('cash')} Pay cash instead</button>
        <p class="sub row" style="justify-content:center;font-size:12px;margin-top:10px">${icon('lock', '', 14)} Paid directly to the captain. RideGo does not hold your money.</p>`;
    } else if (r.paymentMethod === 'cash') {
      payPart = `<div class="panel mt12 row" style="gap:12px">${icon('cash', '', 28)}<div><div class="h-sm">Pay ${money(total)} in cash</div><div class="sub" style="margin:0">${esc(breakdown)}. Please hand the cash to ${esc(d.name)}.</div></div></div>
        <div class="notice amber"><span class="spin"></span><span><b>Waiting for the captain to confirm…</b></span></div>
        ${r.payQr ? `<button class="btn soft" id="payQr">${icon('qr')} Pay by QR instead</button>` : ''}`;
    } else {
      payPart = `<div class="panel mt12 row between"><div><div class="sub" style="margin:0">Total amount payable</div><div class="sub" style="margin:0;font-size:13px">${esc(breakdown)}</div></div><div class="big num green">${money(total)}</div></div>
        ${r.payQr ? `<button class="btn primary" id="payQr">${icon('qr')} Pay ${money(total)} with QR / UPI</button>` : `<div class="notice amber">${icon('help')}<span>This captain has not added a UPI ID, so please pay in cash.</span></div>`}
        <button class="btn soft" id="payCash">${icon('cash')} Pay ${money(total)} cash to driver</button>`;
    }
    sheet.innerHTML = `<div class="grab"></div>
      <div class="row between"><span class="badge green">${icon('checkc', '', 16)} Trip completed</span><b class="muted" style="font-size:13px">Today, ${when()}</b></div>
      <div class="row mt12" style="gap:12px"><span class="avatar lg">${esc(initial(d.name))}</span><div><div class="h-md" style="font-size:20px">Thanks for riding with ${esc(d.name)}!</div><div class="sub" style="margin:0"><span class="green">${icon('star', 'fill', 14)} <b>${d.ratingCount ? d.rating.toFixed(1) : 'New'}</b></span> · ${esc(vInfo(d.vehicleType).label)}${d.vehicleNumber ? ' (' + esc(d.vehicleNumber) + ')' : ''}</div></div></div>
      <div class="panel row between mt12"><div><div class="h-md">Trip fare ${money(r.fare)}</div><div class="sub" style="margin:0">${r.distanceKm} km · ${UI.mins(r.distanceKm)} mins · ${esc(vInfo(r.vehicleType).label)}</div></div></div>
      ${tipBlock(r)}${payPart}`;
    sheet.querySelectorAll('[data-tip]').forEach(b => b.onclick = () => socket.emit('rider:tip', { rideId: r.id, tip: +b.dataset.tip }));
    const pq = $('#payQr'); if (pq) pq.onclick = () => socket.emit('rider:pay', { rideId: r.id, method: 'qr' });
    const pc = $('#payCash'); if (pc) pc.onclick = () => socket.emit('rider:pay', { rideId: r.id, method: 'cash' });
    const cu = $('#copyUpi'); if (cu) cu.onclick = () => UI.copyText(r.upiId);
    const t = $('#maptag'); t.classList.remove('hide'); t.innerHTML = `${icon('checkc', '', 16)} <b>Dropped at ${esc((r.dropName || 'your destination').split(',')[0])}</b>`;
  }

  const COMPS = ['Clean Helmet', 'Safe Driving', 'Polite Captain'];
  function paidView() {
    const r = S.ride, d = r.driver || { name: 'Captain' }, total = r.total ?? r.fare;
    const how = r.paymentMethod === 'qr' ? 'Paid successfully via UPI' : 'Paid in cash';
    sheet.innerHTML = `<div class="grab"></div>
      <div style="text-align:center"><div class="check-hero">${icon('check')}</div><span class="badge green">${icon('checkc', '', 16)} Payment received</span>
        <div class="big num mt8">${money(total)}</div><div class="sub">${how}</div></div>
      ${r.tip ? `<div class="notice peach">${icon('heart')}<span>Includes <b>${money(r.tip)} tip</b> for your captain. Thank you!</span></div>` : ''}
      <div class="panel row mt12" style="gap:12px"><span class="avatar">${esc(initial(d.name))}</span><div><b style="font-size:16px">Captain ${esc(d.name)}</b><div class="sub" style="margin:0">Confirmed receipt of your payment</div></div></div>
      ${S.rated ? `<div class="notice ok mt12">${icon('checkc')}<span>Thanks for your feedback!</span></div>` : `<div class="card mt12" style="text-align:center"><h2 class="h-sm">Rate your ride with ${esc(d.name)}</h2><p class="sub">Help keep RideGo high-quality and safe</p>
        <div class="stars">${[1, 2, 3, 4, 5].map(i => `<button data-star="${i}" class="${S.rating >= i ? 'on' : ''}" aria-label="${i} star${i > 1 ? 's' : ''}">${icon('star')}</button>`).join('')}</div>
        <div class="sub" style="font-weight:600;margin-bottom:6px">Give Captain ${esc(d.name)} a compliment:</div>
        <div class="chips" style="justify-content:center">${COMPS.map(c => `<button class="chip sm ${S.compliments.includes(c) ? 'on' : ''}" data-comp="${esc(c)}">${esc(c)}</button>`).join('')}</div>
        <button class="btn primary" id="rate" ${S.rating ? '' : 'disabled'}>Submit rating</button></div>`}
      <button class="btn dark" id="another">${UI.bikeSvg} Book another ride</button>`;
    sheet.querySelectorAll('[data-star]').forEach(b => b.onclick = () => { S.rating = +b.dataset.star; paidView(); UI.sheetHeight(); });
    sheet.querySelectorAll('[data-comp]').forEach(b => b.onclick = () => { const c = b.dataset.comp; S.compliments = S.compliments.includes(c) ? S.compliments.filter(x => x !== c) : [...S.compliments, c]; paidView(); });
    const rt = $('#rate'); if (rt) rt.onclick = () => socket.emit('rider:rate', { rideId: r.id, stars: S.rating, compliments: S.compliments }, res => {
      if (res && res.ok) { S.rated = true; paidView(); UI.toast('Thanks for rating!'); } else UI.toast((res && res.error) || 'Could not save rating'); });
    $('#another').onclick = fullReset;
    const t = $('#maptag'); t.classList.remove('hide'); t.innerHTML = `<b>Trip completed</b>`;
  }

  // ---------- ride updates from the server ----------
  let lastStatus = null, fittedForRide = null;
  function applyRide(r) {
    const prevPaid = S.ride && S.ride.paymentStatus === 'paid';
    S.ride = { ...(S.ride || {}), ...r };
    if (r.pickup && !S.pickup) { S.pickup = r.pickup; S.drop = r.drop; }
    const st = r.status;
    if (st === 'cancelled') { UI.toast('Ride cancelled'); S.phase = 'home'; clearLayer('bike'); S.ride = null; drawMap(); render(); lastStatus = st; return; }
    if (st === 'no_drivers') S.phase = 'nodrivers';
    else if (st === 'searching') S.phase = 'searching';
    else if (['accepted', 'arrived', 'started'].includes(st)) S.phase = 'active';
    else if (st === 'completed') S.phase = r.paymentStatus === 'paid' ? 'paid' : 'done';
    if (S.phase === 'paid' && !prevPaid) UI.celebrate();
    if (r.driver && r.driver.lat != null && ['accepted', 'arrived', 'started'].includes(st)) {
      const ll = [r.driver.lat, r.driver.lng];
      if (!L_.bike) L_.bike = L.marker(ll, { icon: UI.iconBike() }).addTo(map); else L_.bike.setLatLng(ll);
      if (fittedForRide !== r.id + st) { fittedForRide = r.id + st; map.fitBounds([ll, st === 'started' ? [r.drop.lat, r.drop.lng] : [r.pickup.lat, r.pickup.lng]], { paddingTopLeft: [40, 110], paddingBottomRight: [40, 400], maxZoom: 17 }); }
    }
    if (['completed', 'no_drivers'].includes(st)) clearLayer('bike');
    drawMap(); render();
    if (S.phase === 'done') sheet.scrollTop = 0;
    lastStatus = st;
  }
  socket.on('ride:update', applyRide);
  socket.on('connect', () => socket.emit('rider:resume', r => { if (r) applyRide(r); }));

  function fullReset() {
    clearLayer('bike'); clearLayer('wave');
    Object.assign(S, { phase: 'home', mode: 'drop', pickup: null, drop: null, pickupPlace: null, dropPlace: null, est: null, ride: null, results: [], searchMsg: '', rating: 0, compliments: [], rated: false });
    drawMap(); render(); loadRecent();
    if (S.myLoc) setPickup({ ...S.myLoc }); else locate(true);
  }
  async function loadRecent() {
    try { const h = await UI.api('/api/history'); const seen = new Set();
      S.recent = h.rides.filter(r => r.status === 'completed' && r.drop && r.dropLat != null && !seen.has(r.drop) && seen.add(r.drop)).slice(0, 4); if (S.phase === 'home') render(); } catch {}
  }

  // ---------- chrome ----------
  $('#locBtn').onclick = () => { locate(S.phase === 'home'); };
  const openTrips = () => Pages.openTrips({ role: 'rider', onBookAgain: r => {
    fullReset(); setTimeout(() => { setPickup({ lat: r.pickupLat, lng: r.pickupLng }, r.pickup ? splitName(r.pickup) : null); setDrop({ lat: r.dropLat, lng: r.dropLng }, r.drop ? splitName(r.drop) : null); }, 50); } });
  const openAcct = () => Pages.openAccount({ user, role: 'rider' });
  $('#pHist').onclick = openTrips; $('#pOut').onclick = () => RideAuth.logout(); $('#prof').onclick = openAcct;
  document.querySelectorAll('.nav button').forEach(b => b.onclick = () => { const k = b.dataset.nav; if (k === 'trips') openTrips(); else if (k === 'acct') openAcct(); });

  UI.api('/api/vehicles').then(v => { S.vehicles = v.vehicles; S.vehicle = v.vehicles[0] && v.vehicles[0].id; });
  render(); loadRecent(); locate(true);
});
