// RideGo server: login, database, and real-time ride matching.
const express = require('express');
const http = require('http');
const crypto = require('crypto');
const { Server } = require('socket.io');
const { DatabaseSync } = require('node:sqlite');
const QRCode = require('qrcode');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.json());
app.use(express.static('public'));
app.use('/leaflet', express.static('node_modules/leaflet/dist'));

// ---- Settings (change these to change behaviour) ----
// Vehicle types. To launch autos or cabs later, just set enabled: true (and adjust prices).
const VEHICLES = {
  bike: { label: 'Bike',  icon: '🏍️', base: 10, perKm: 8,  enabled: true,  note: 'Wear a helmet. 1 passenger only.' },
  auto: { label: 'Auto',  icon: '🛺', base: 30, perKm: 11, enabled: false, note: 'Up to 3 passengers.' },
  cab:  { label: 'Cab',   icon: '🚕', base: 50, perKm: 14, enabled: false, note: 'Up to 4 passengers.' },
};
const enabledVehicles = () => Object.entries(VEHICLES).filter(([, v]) => v.enabled).map(([id, v]) => ({ id, ...v }));
const isVehicle = t => VEHICLES[t] && VEHICLES[t].enabled;
const OFFER_SECONDS = 15;  // how long a driver has to accept
const MAX_PICKUP_KM = 5;   // only look for drivers this close
// OTP_MODE "demo": the code is shown on screen (no SMS needed). Switch to real SMS later.
const OTP_MODE = process.env.OTP_MODE || 'demo';

// ---- Database (a single file called ridego.db, created automatically) ----
const db = new DatabaseSync(process.env.DB_FILE || 'ridego.db');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('rider','driver')),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS rides (
  id INTEGER PRIMARY KEY AUTOINCREMENT, rider_id INTEGER NOT NULL, driver_id INTEGER,
  pickup_lat REAL, pickup_lng REAL, drop_lat REAL, drop_lng REAL,
  distance_km REAL, fare INTEGER, status TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, completed_at TEXT);
`);
// Upgrade older databases (from earlier versions) by adding the new columns
const hasCol = (t, c) => db.prepare(`PRAGMA table_info(${t})`).all().some(x => x.name === c);
if (!hasCol('users', 'vehicle_type')) db.exec(`ALTER TABLE users ADD COLUMN vehicle_type TEXT`);
if (!hasCol('users', 'vehicle_number')) db.exec(`ALTER TABLE users ADD COLUMN vehicle_number TEXT`);
if (!hasCol('rides', 'vehicle_type')) db.exec(`ALTER TABLE rides ADD COLUMN vehicle_type TEXT`);
if (!hasCol('users', 'upi_id')) db.exec(`ALTER TABLE users ADD COLUMN upi_id TEXT`);
if (!hasCol('rides', 'tip')) db.exec(`ALTER TABLE rides ADD COLUMN tip INTEGER DEFAULT 0`);
if (!hasCol('rides', 'payment_method')) db.exec(`ALTER TABLE rides ADD COLUMN payment_method TEXT`);
if (!hasCol('rides', 'payment_status')) db.exec(`ALTER TABLE rides ADD COLUMN payment_status TEXT`);
db.exec(`UPDATE rides SET payment_status='paid', payment_method=COALESCE(payment_method,'cash') WHERE status='completed' AND payment_status IS NULL`);
db.exec(`UPDATE users SET vehicle_type='bike', vehicle_number=COALESCE(vehicle_number,'NOT SET') WHERE role='driver' AND vehicle_type IS NULL`);
db.exec(`UPDATE rides SET vehicle_type='bike' WHERE vehicle_type IS NULL`);
// Rides left half-finished by a restart are marked cancelled
db.exec(`UPDATE rides SET status='cancelled' WHERE status IN ('searching','accepted','arrived','started')`);

const q = {
  userByPhone: db.prepare('SELECT * FROM users WHERE phone=?'),
  userById: db.prepare('SELECT * FROM users WHERE id=?'),
  addUser: db.prepare('INSERT INTO users (phone,name,role,vehicle_type,vehicle_number,upi_id) VALUES (?,?,?,?,?,?)'),
  setTip: db.prepare('UPDATE rides SET tip=? WHERE id=?'),
  setUpi: db.prepare('UPDATE users SET upi_id=? WHERE id=?'),
  setPay: db.prepare('UPDATE rides SET payment_method=?, payment_status=? WHERE id=?'),
  addSession: db.prepare('INSERT INTO sessions (token,user_id) VALUES (?,?)'),
  userByToken: db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?'),
  delSession: db.prepare('DELETE FROM sessions WHERE token=?'),
  addRide: db.prepare(`INSERT INTO rides (rider_id,pickup_lat,pickup_lng,drop_lat,drop_lng,distance_km,fare,status,vehicle_type)
                       VALUES (?,?,?,?,?,?,?,?,?)`),
  setRide: db.prepare(`UPDATE rides SET status=?, driver_id=?, completed_at=CASE WHEN ?='completed' THEN CURRENT_TIMESTAMP ELSE completed_at END WHERE id=?`),
  historyRider: db.prepare(`SELECT r.*, d.name AS other_name FROM rides r LEFT JOIN users d ON d.id=r.driver_id
                            WHERE r.rider_id=? ORDER BY r.id DESC LIMIT 50`),
  historyDriver: db.prepare(`SELECT r.*, u.name AS other_name FROM rides r JOIN users u ON u.id=r.rider_id
                             WHERE r.driver_id=? ORDER BY r.id DESC LIMIT 50`),
  earnings: db.prepare(`SELECT COALESCE(SUM(fare+COALESCE(tip,0)),0) AS total, COUNT(*) AS trips FROM rides WHERE driver_id=? AND status='completed'`),
  spent: db.prepare(`SELECT COALESCE(SUM(fare+COALESCE(tip,0)),0) AS total, COUNT(*) AS trips FROM rides WHERE rider_id=? AND status='completed'`),
};

// ---------- LOGIN (phone + OTP) ----------
const otps = new Map();      // phone -> {code, expires, tries}
const otpAsks = new Map();   // phone -> [timestamps]  (to stop spamming)
const cleanPhone = p => String(p || '').replace(/\D/g, '').slice(-10);
const validPhone = p => /^[6-9]\d{9}$/.test(p); // 10-digit Indian mobile number
const publicUser = u => ({ id: u.id, phone: u.phone, name: u.name, role: u.role, vehicleType: u.vehicle_type, vehicleNumber: u.vehicle_number, upiId: u.upi_id });
// UPI ID like name@okaxis. Returns null if empty, false if invalid.
const cleanUpi = v => { const t = String(v || '').trim().toLowerCase(); if (!t) return null; return /^[a-z0-9._-]{2,}@[a-z]{2,}$/.test(t) ? t : false; };
app.get('/api/vehicles', (req, res) => res.json({ vehicles: enabledVehicles() }));

app.post('/api/otp/request', (req, res) => {
  const phone = cleanPhone(req.body.phone);
  if (!validPhone(phone)) return res.status(400).json({ error: 'Enter a valid 10-digit mobile number.' });
  const now = Date.now();
  const recent = (otpAsks.get(phone) || []).filter(t => now - t < 10 * 60000);
  if (recent.length >= 5) return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  otpAsks.set(phone, [...recent, now]);
  const code = String(crypto.randomInt(100000, 1000000));
  otps.set(phone, { code, expires: now + 5 * 60000, tries: 0 });
  // To send real SMS later, call your SMS provider (e.g. Twilio, MSG91) right here.
  console.log(`[OTP] ${phone}: ${code}`);
  const existing = q.userByPhone.get(phone);
  res.json({ ok: true, isNew: !existing, role: existing && existing.role, demoOtp: OTP_MODE === 'demo' ? code : undefined });
});

app.post('/api/otp/verify', (req, res) => {
  const phone = cleanPhone(req.body.phone), { otp, name, role } = req.body;
  const rec = otps.get(phone);
  if (!rec || rec.expires < Date.now()) return res.status(400).json({ error: 'Code expired. Request a new one.' });
  if (++rec.tries > 5) { otps.delete(phone); return res.status(429).json({ error: 'Too many wrong tries. Request a new code.' }); }
  if (String(otp) !== rec.code) return res.status(400).json({ error: 'Wrong code. Please try again.' });
  let user = q.userByPhone.get(phone);
  if (!user) {
    const cleanName = String(name || '').trim().slice(0, 40);
    if (!cleanName) return res.status(400).json({ error: 'Please enter your name.' });
    if (!['rider', 'driver'].includes(role)) return res.status(400).json({ error: 'Invalid role.' });
    let vType = null, vNum = null, upi = null;
    if (role === 'driver') {
      vType = req.body.vehicleType; vNum = String(req.body.vehicleNumber || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (!isVehicle(vType)) return res.status(400).json({ error: 'Please choose your vehicle type.' });
      if (vNum.length < 6 || vNum.length > 12) return res.status(400).json({ error: 'Enter your number plate (for example TS09AB1234).' });
      upi = cleanUpi(req.body.upiId);
      if (upi === false) return res.status(400).json({ error: 'That UPI ID does not look right (example: name@okaxis).' });
    }
    q.addUser.run(phone, cleanName, role, vType, vNum, upi);
    user = q.userByPhone.get(phone);
  } else if (role && user.role !== role) {
    return res.status(403).json({ error: `This number is registered as a ${user.role}. Use the ${user.role} page.` });
  }
  otps.delete(phone);
  const token = crypto.randomBytes(24).toString('hex');
  q.addSession.run(token, user.id);
  res.json({ token, user: publicUser(user) });
});

const auth = (req, res, next) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const user = token && q.userByToken.get(token);
  if (!user) return res.status(401).json({ error: 'Please log in again.' });
  req.user = user; req.token = token; next();
};
app.post('/api/upi', auth, (req, res) => {
  if (req.user.role !== 'driver') return res.status(403).json({ error: 'Only drivers can set a UPI ID.' });
  const upi = cleanUpi(req.body.upiId);
  if (upi === false) return res.status(400).json({ error: 'That UPI ID does not look right (example: name@okaxis).' });
  q.setUpi.run(upi, req.user.id); res.json({ ok: true, upiId: upi });
});
app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
app.post('/api/logout', auth, (req, res) => { q.delSession.run(req.token); res.json({ ok: true }); });
app.get('/api/history', auth, (req, res) => {
  const isDriver = req.user.role === 'driver';
  const rows = (isDriver ? q.historyDriver : q.historyRider).all(req.user.id);
  const sum = (isDriver ? q.earnings : q.spent).get(req.user.id);
  res.json({
    role: req.user.role, total: sum.total, trips: sum.trips,
    rides: rows.map(r => ({ id: r.id, status: r.status, fare: r.fare, distanceKm: r.distance_km,
      tip: r.tip || 0,
      vehicle: VEHICLES[r.vehicle_type] ? VEHICLES[r.vehicle_type].label : 'Ride',
      payment: r.status === 'completed' ? `${r.payment_method === 'qr' ? 'QR' : 'Cash'} · ${r.payment_status === 'paid' ? 'paid' : 'unpaid'}` : '',
      other: r.other_name, date: r.created_at })),
  });
});

// ---------- LIVE RIDES ----------
const drivers = new Map(); // socketId -> {id,userId,name,lat,lng,busy}
const rides = new Map();   // rideId -> live ride (only while active)

function km(a, b) {
  const R = 6371, rad = d => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
const fareFor = (type, distKm) => Math.round(VEHICLES[type].base + VEHICLES[type].perKm * distKm);
const validPt = p => p && Number.isFinite(p.lat) && Number.isFinite(p.lng) && Math.abs(p.lat) <= 90 && Math.abs(p.lng) <= 180;

function saveRide(r) { q.setRide.run(r.status, r.driverUserId || null, r.status, r.id); }
function publicRide(r) {
  const d = r.driverId && drivers.get(r.driverId);
  return {
    id: r.id, status: r.status, pickup: r.pickup, drop: r.drop, vehicleType: r.vehicleType,
    distanceKm: r.distanceKm, fare: r.fare, riderName: r.riderName,
    tip: r.tip || 0, total: r.fare + (r.tip || 0), upiId: r.upiId || null, paymentMethod: r.paymentMethod || null, paymentStatus: r.paymentStatus || null, payQr: r.payQr || null, payUri: r.payUri || null,
    driver: d ? { name: d.name, lat: d.lat, lng: d.lng, vehicleType: d.vehicleType, vehicleNumber: d.vehicleNumber } : r.driverInfo || null,
  };
}
function notifyRider(r) { io.to('ride:' + r.id).emit('ride:update', publicRide(r)); }
function finish(r) {
  saveRide(r);
  if (r.status === 'completed') { r.paymentStatus = 'pending'; q.setPay.run(null, 'pending', r.id); } // stays until payment is confirmed
  else if (['cancelled', 'no_drivers'].includes(r.status)) rides.delete(r.id);
}
// (Re)build the UPI payment QR for fare + tip
async function makeQr(r) {
  if (!r.upiId) return;
  const amount = r.fare + (r.tip || 0);
  r.payUri = `upi://pay?pa=${encodeURIComponent(r.upiId)}&pn=${encodeURIComponent(r.upiName || 'Driver')}&am=${amount}&cu=INR&tn=${encodeURIComponent('RideGo trip ' + r.id)}`;
  try { r.payQr = await QRCode.toDataURL(r.payUri, { margin: 1, width: 260 }); } catch { r.payUri = null; r.payQr = null; }
}
const isActive = r => !['completed', 'cancelled', 'no_drivers'].includes(r.status);

function offerRide(r) {
  const candidates = [...drivers.values()]
    .filter(d => !d.busy && d.vehicleType === r.vehicleType && !r.asked.has(d.id) && km(d, r.pickup) <= MAX_PICKUP_KM)
    .sort((a, b) => km(a, r.pickup) - km(b, r.pickup));
  if (!candidates.length) { r.status = 'no_drivers'; finish(r); return notifyRider(r); }
  const d = candidates[0];
  r.asked.add(d.id); r.offeredTo = d.id; r.status = 'searching';
  saveRide(r); notifyRider(r);
  io.to(d.id).emit('driver:offer', { ...publicRide(r), pickupDistanceKm: +km(d, r.pickup).toFixed(1), seconds: OFFER_SECONDS });
  clearTimeout(r.timer);
  r.timer = setTimeout(() => {
    if (r.status === 'searching' && r.offeredTo === d.id) {
      io.to(d.id).emit('driver:offer_expired', { id: r.id });
      offerRide(r);
    }
  }, OFFER_SECONDS * 1000);
}

// Only logged-in users can connect; the server knows who they are and their role.
io.use((socket, next) => {
  const user = socket.handshake.auth && socket.handshake.auth.token && q.userByToken.get(socket.handshake.auth.token);
  if (!user) return next(new Error('unauthorized'));
  socket.user = user; next();
});

io.on('connection', socket => {
  const user = socket.user;
  socket.join('user:' + user.id);

  if (user.role === 'driver') {
    socket.on('driver:online', ({ lat, lng }) => {
      if (!validPt({ lat, lng })) return;
      drivers.set(socket.id, { id: socket.id, userId: user.id, name: user.name, vehicleType: user.vehicle_type, vehicleNumber: user.vehicle_number, lat, lng, busy: false });
    });
    socket.on('driver:location', ({ lat, lng }) => {
      const d = drivers.get(socket.id);
      if (!d || !validPt({ lat, lng })) return;
      d.lat = lat; d.lng = lng;
      for (const r of rides.values())
        if (r.driverId === socket.id && ['accepted', 'arrived', 'started'].includes(r.status)) notifyRider(r);
    });
    socket.on('driver:offline', () => {
      const d = drivers.get(socket.id);
      if (d && !d.busy) drivers.delete(socket.id);
    });
    socket.on('driver:accept', ({ rideId }) => {
      const r = rides.get(rideId), d = drivers.get(socket.id);
      if (!r || !d || r.status !== 'searching' || r.offeredTo !== socket.id) return;
      clearTimeout(r.timer);
      r.driverId = socket.id; r.driverUserId = user.id; r.status = 'accepted'; d.busy = true;
      saveRide(r);
      socket.emit('driver:ride', publicRide(r)); notifyRider(r);
    });
    socket.on('driver:reject', ({ rideId }) => {
      const r = rides.get(rideId);
      if (!r || r.status !== 'searching' || r.offeredTo !== socket.id) return;
      clearTimeout(r.timer); offerRide(r);
    });
    const advance = (event, from, to) => socket.on(event, async ({ rideId }) => {
      const r = rides.get(rideId);
      if (!r || r.driverId !== socket.id || r.status !== from) return;
      r.status = to;
      if (to === 'completed') {
        r.driverInfo = { name: user.name, vehicleType: user.vehicle_type, vehicleNumber: user.vehicle_number };
        const d = drivers.get(socket.id); if (d) d.busy = false;
        // Build a payment QR from the driver's UPI ID (money goes straight from rider to driver)
        const fresh = q.userById.get(user.id);
        if (fresh && fresh.upi_id) { r.upiId = fresh.upi_id; r.upiName = fresh.name; await makeQr(r); }
      }
      finish(r); notifyRider(r); socket.emit('driver:ride', publicRide(r));
    });
    advance('driver:arrived', 'accepted', 'arrived');
    advance('driver:start', 'arrived', 'started');
    advance('driver:complete', 'started', 'completed');

    // Driver confirms the money arrived (cash in hand, or UPI credited)
    socket.on('driver:payment_received', ({ rideId }) => {
      const r = rides.get(rideId);
      if (!r || r.driverUserId !== user.id || r.status !== 'completed' || r.paymentStatus === 'paid') return;
      r.paymentMethod = r.paymentMethod || 'cash'; r.paymentStatus = 'paid';
      q.setPay.run(r.paymentMethod, 'paid', r.id);
      notifyRider(r); io.to('user:' + user.id).emit('driver:ride', publicRide(r));
      rides.delete(r.id);
    });
    // After a page refresh, show any trip still waiting for payment
    for (const r of rides.values())
      if (r.driverUserId === user.id && r.status === 'completed' && r.paymentStatus !== 'paid') socket.emit('driver:ride', publicRide(r));
  }

  if (user.role === 'rider') {
    socket.on('rider:estimate', ({ pickup, drop }, cb) => {
      if (typeof cb !== 'function' || !validPt(pickup) || !validPt(drop)) return;
      const distanceKm = +km(pickup, drop).toFixed(1);
      // Send a fare for every available vehicle type so the rider can compare
      cb({ distanceKm, fares: Object.fromEntries(enabledVehicles().map(v => [v.id, fareFor(v.id, distanceKm)])) });
    });
    socket.on('rider:request', ({ pickup, drop, vehicleType }, cb) => {
      if (typeof cb !== 'function' || !validPt(pickup) || !validPt(drop)) return;
      if (!isVehicle(vehicleType)) return cb({ error: 'Please choose a vehicle type.' });
      // One active ride at a time
      for (const x of rides.values()) if (x.riderUserId === user.id && isActive(x)) return cb({ error: 'You already have an active ride.' });
      for (const x of [...rides.values()]) if (x.riderUserId === user.id) rides.delete(x.id); // forget old unpaid trips (they stay in history)
      const distanceKm = +km(pickup, drop).toFixed(1), fare = fareFor(vehicleType, distanceKm);
      const info = q.addRide.run(user.id, pickup.lat, pickup.lng, drop.lat, drop.lng, distanceKm, fare, 'searching', vehicleType);
      const r = { id: Number(info.lastInsertRowid), status: 'searching', riderName: user.name, riderUserId: user.id,
        pickup, drop, vehicleType, distanceKm, fare, asked: new Set(), driverId: null };
      rides.set(r.id, r);
      socket.join('ride:' + r.id);
      cb({ rideId: r.id });
      offerRide(r);
    });
    socket.on('rider:cancel', ({ rideId }) => {
      const r = rides.get(rideId);
      if (!r || r.riderUserId !== user.id || ['completed', 'cancelled', 'started'].includes(r.status)) return;
      clearTimeout(r.timer);
      const d = r.driverId && drivers.get(r.driverId);
      if (d) { d.busy = false; io.to(r.driverId).emit('driver:cancelled', { id: r.id }); }
      if (r.offeredTo) io.to(r.offeredTo).emit('driver:offer_expired', { id: r.id });
      r.status = 'cancelled'; finish(r); notifyRider(r);
    });
    // Rider adds an optional tip for the captain: 0, or any whole number from 5 to 50
    socket.on('rider:tip', async ({ rideId, tip }) => {
      const r = rides.get(rideId);
      if (!r || r.riderUserId !== user.id || r.status !== 'completed' || r.paymentStatus === 'paid') return;
      if (!Number.isInteger(tip) || !(tip === 0 || (tip >= 5 && tip <= 50))) return;
      r.tip = tip; q.setTip.run(tip, r.id);
      await makeQr(r);
      notifyRider(r); io.to('user:' + r.driverUserId).emit('driver:ride', publicRide(r));
    });
    // Rider chooses how to pay after the trip: 'qr' or 'cash'
    socket.on('rider:pay', ({ rideId, method }) => {
      const r = rides.get(rideId);
      if (!r || r.riderUserId !== user.id || r.status !== 'completed' || r.paymentStatus === 'paid') return;
      if (!['qr', 'cash'].includes(method) || (method === 'qr' && !r.payQr)) return;
      r.paymentMethod = method; q.setPay.run(method, 'pending', r.id);
      notifyRider(r); io.to('user:' + r.driverUserId).emit('driver:ride', publicRide(r));
    });
    // If a rider reconnects mid-ride (page refresh), send them the current state
    socket.on('rider:resume', cb => {
      for (const r of rides.values()) if (r.riderUserId === user.id) {
        socket.join('ride:' + r.id);
        return typeof cb === 'function' && cb(publicRide(r));
      }
      typeof cb === 'function' && cb(null);
    });
  }

  socket.on('disconnect', () => {
    const d = drivers.get(socket.id);
    drivers.delete(socket.id);
    if (d) for (const r of rides.values()) {
      if (r.driverId === socket.id && ['accepted', 'arrived'].includes(r.status)) {
        r.driverId = null; r.driverUserId = null; r.asked.add(socket.id); offerRide(r); // find another driver
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`RideGo running at http://localhost:${PORT}`));
