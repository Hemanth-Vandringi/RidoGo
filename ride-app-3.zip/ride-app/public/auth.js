// Shared login + trip history for rider.html and driver.html.
// Usage: RideAuth.start('rider', (token, user) => { ...start the page... });
const RideAuth = (() => {
  const KEY = 'ridego_token';
  const get = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
  const set = t => { try { t ? localStorage.setItem(KEY, t) : localStorage.removeItem(KEY); } catch {} };
  const api = async (path, opts = {}) => {
    const res = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json',
      ...(get() ? { Authorization: 'Bearer ' + get() } : {}) }, body: opts.body && JSON.stringify(opts.body) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function el(html) { const d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild; }

  function showLogin(role, done) {
    const ov = el(`<div class="overlay"><div class="card">
      <h2>${role === 'driver' ? 'Driver login' : 'Rider login'}</h2>
      <div id="s1"><p>Enter your mobile number. We will send you a code.</p>
        <input id="ph" type="tel" inputmode="numeric" maxlength="10" placeholder="10-digit mobile number">
        <button id="send">Send code</button></div>
      <div id="s2" class="hide"><p id="demo" class="demo hide"></p><p>Enter the 6-digit code.</p>
        <input id="otp" inputmode="numeric" maxlength="6" placeholder="6-digit code">
        <input id="nm" class="hide" placeholder="Your name (first time only)">
        <div id="vh" class="hide"><p>Your vehicle (first time only)</p>
          <select id="vt"></select>
          <input id="vn" placeholder="Number plate, e.g. TS09AB1234" maxlength="14">
          <input id="vu" placeholder="UPI ID for QR payments (optional), e.g. name@okaxis" maxlength="60"></div>
        <button id="ver">Verify and continue</button><button id="back" class="sec">Change number</button></div>
      <p id="err" class="err"></p></div></div>`);
    document.body.appendChild(ov);
    const $ = s => ov.querySelector(s); let phone = '';
    const err = m => $('#err').textContent = m || '';
    $('#send').onclick = async () => {
      err(); phone = $('#ph').value.trim();
      try {
        const r = await api('/api/otp/request', { method: 'POST', body: { phone } });
        $('#s1').classList.add('hide'); $('#s2').classList.remove('hide');
        if (r.isNew) $('#nm').classList.remove('hide');
        if (r.isNew && role === 'driver') {
          const { vehicles } = await api('/api/vehicles');
          $('#vt').innerHTML = vehicles.map(v => `<option value="${esc(v.id)}">${esc(v.icon)} ${esc(v.label)}</option>`).join('');
          $('#vh').classList.remove('hide');
        }
        if (r.demoOtp) { $('#demo').classList.remove('hide'); $('#demo').innerHTML = `Demo mode: your code is <b>${r.demoOtp}</b>`; }
      } catch (e) { err(e.message); }
    };
    $('#back').onclick = () => { err(); $('#s2').classList.add('hide'); $('#s1').classList.remove('hide'); };
    $('#ver').onclick = async () => {
      err();
      try {
        const r = await api('/api/otp/verify', { method: 'POST', body: { phone, otp: $('#otp').value.trim(), name: $('#nm').value, role, vehicleType: $('#vt').value, vehicleNumber: $('#vn').value, upiId: $('#vu').value } });
        set(r.token); ov.remove(); done(r.token, r.user);
      } catch (e) { err(e.message); }
    };
  }

  function addBar(user) {
    const bar = el(`<div class="topbar"><span>${esc(user.name)}${user.vehicleNumber ? ' · ' + esc(user.vehicleNumber) : ''}</span><button id="hbtn">My trips</button><button id="lbtn">Log out</button></div>`);
    document.body.appendChild(bar);
    bar.querySelector('#lbtn').onclick = async () => { try { await api('/api/logout', { method: 'POST' }); } catch {} set(null); location.reload(); };
    bar.querySelector('#hbtn').onclick = async () => {
      let h; try { h = await api('/api/history'); } catch (e) { return alert(e.message); }
      const label = h.role === 'driver' ? 'Total earned' : 'Total spent';
      const rows = h.rides.map(r => `<div class="row"><div><b>${esc(r.other || 'No driver')}</b><br><small>${esc(r.vehicle)} · ${esc(r.date)} · ${r.distanceKm} km</small></div>
        <div style="text-align:right"><b>₹${r.fare + (r.tip || 0)}</b><br><small>${esc(r.status)}${r.payment ? ' · ' + esc(r.payment) : ''}${r.tip ? ' · tip ₹' + r.tip : ''}</small></div></div>`).join('') || '<p>No trips yet.</p>';
      const m = el(`<div class="overlay"><div class="card"><h2>My trips</h2>
        <p>${label}: <b>₹${h.total}</b> across ${h.trips} completed trip(s)</p><div class="list">${rows}</div><button class="sec" id="x">Close</button></div></div>`);
      m.querySelector('#x').onclick = () => m.remove(); document.body.appendChild(m);
    };
  }

  async function start(role, onReady) {
    if (get()) {
      try {
        const { user } = await api('/api/me');
        if (user.role === role) { addBar(user); return onReady(get(), user); }
        set(null); // logged in as the other role: log in again
      } catch { set(null); }
    }
    showLogin(role, (token, user) => { addBar(user); onReady(token, user); });
  }
  return { start, api };
})();
