// RideGo server: handles riders, drivers, and ride matching in real time.
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static('public'));
app.use('/leaflet', express.static('node_modules/leaflet/dist'));

// ---- Fare settings (change these to change prices) ----
const BASE_FARE = 30;      // rupees
const PER_KM = 12;         // rupees per km
const OFFER_SECONDS = 15;  // how long a driver has to accept
const MAX_PICKUP_KM = 5;   // only look for drivers this close

// ---- In-memory data (resets when server restarts) ----
const drivers = new Map(); // socketId -> {id,name,lat,lng,busy}
const rides = new Map();   // rideId -> ride
let rideCounter = 1;

function km(a, b) {
  const R = 6371, rad = d => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
const fareFor = distKm => Math.round(BASE_FARE + PER_KM * distKm);

function publicRide(r) {
  const d = r.driverId && drivers.get(r.driverId);
  return {
    id: r.id, status: r.status, pickup: r.pickup, drop: r.drop,
    distanceKm: r.distanceKm, fare: r.fare, riderName: r.riderName,
    driver: d ? { name: d.name, lat: d.lat, lng: d.lng } : r.driverInfo || null,
  };
}
function notifyRider(r) { io.to('ride:' + r.id).emit('ride:update', publicRide(r)); }

// Offer the ride to the nearest free driver who hasn't been asked yet.
function offerRide(r) {
  const candidates = [...drivers.values()]
    .filter(d => !d.busy && !r.asked.has(d.id) && km(d, r.pickup) <= MAX_PICKUP_KM)
    .sort((a, b) => km(a, r.pickup) - km(b, r.pickup));
  if (!candidates.length) {
    r.status = 'no_drivers';
    return notifyRider(r);
  }
  const d = candidates[0];
  r.asked.add(d.id);
  r.offeredTo = d.id;
  r.status = 'searching';
  notifyRider(r);
  io.to(d.id).emit('driver:offer', {
    ...publicRide(r), pickupDistanceKm: +km(d, r.pickup).toFixed(1), seconds: OFFER_SECONDS,
  });
  clearTimeout(r.timer);
  r.timer = setTimeout(() => {
    if (r.status === 'searching' && r.offeredTo === d.id) {
      io.to(d.id).emit('driver:offer_expired', { id: r.id });
      offerRide(r);
    }
  }, OFFER_SECONDS * 1000);
}

io.on('connection', socket => {
  // ---------- DRIVER ----------
  socket.on('driver:online', ({ name, lat, lng }) => {
    drivers.set(socket.id, { id: socket.id, name: name || 'Driver', lat, lng, busy: false });
  });
  socket.on('driver:location', ({ lat, lng }) => {
    const d = drivers.get(socket.id);
    if (!d) return;
    d.lat = lat; d.lng = lng;
    // Send live position to the rider of the active ride
    for (const r of rides.values()) {
      if (r.driverId === socket.id && ['accepted', 'arrived', 'started'].includes(r.status)) notifyRider(r);
    }
  });
  socket.on('driver:offline', () => drivers.delete(socket.id));

  socket.on('driver:accept', ({ rideId }) => {
    const r = rides.get(rideId), d = drivers.get(socket.id);
    if (!r || !d || r.status !== 'searching' || r.offeredTo !== socket.id) return;
    clearTimeout(r.timer);
    r.driverId = socket.id; r.status = 'accepted'; d.busy = true;
    socket.emit('driver:ride', publicRide(r));
    notifyRider(r);
  });
  socket.on('driver:reject', ({ rideId }) => {
    const r = rides.get(rideId);
    if (!r || r.status !== 'searching' || r.offeredTo !== socket.id) return;
    clearTimeout(r.timer);
    offerRide(r);
  });
  // Driver moves ride along: arrived -> started -> completed
  const advance = (event, from, to) => socket.on(event, ({ rideId }) => {
    const r = rides.get(rideId);
    if (!r || r.driverId !== socket.id || r.status !== from) return;
    r.status = to;
    if (to === 'completed') {
      const d = drivers.get(socket.id);
      r.driverInfo = d ? { name: d.name } : null;
      if (d) d.busy = false;
    }
    notifyRider(r);
    socket.emit('driver:ride', publicRide(r));
  });
  advance('driver:arrived', 'accepted', 'arrived');
  advance('driver:start', 'arrived', 'started');
  advance('driver:complete', 'started', 'completed');

  // ---------- RIDER ----------
  socket.on('rider:estimate', ({ pickup, drop }, cb) => {
    const distanceKm = +km(pickup, drop).toFixed(1);
    cb({ distanceKm, fare: fareFor(distanceKm) });
  });
  socket.on('rider:request', ({ name, pickup, drop }, cb) => {
    const distanceKm = +km(pickup, drop).toFixed(1);
    const r = {
      id: rideCounter++, status: 'searching', riderName: name || 'Rider',
      pickup, drop, distanceKm, fare: fareFor(distanceKm),
      riderSocket: socket.id, asked: new Set(), driverId: null,
    };
    rides.set(r.id, r);
    socket.join('ride:' + r.id);
    cb({ rideId: r.id });
    offerRide(r);
  });
  socket.on('rider:cancel', ({ rideId }) => {
    const r = rides.get(rideId);
    if (!r || ['completed', 'cancelled', 'started'].includes(r.status)) return;
    clearTimeout(r.timer);
    if (r.driverId && drivers.get(r.driverId)) {
      drivers.get(r.driverId).busy = false;
      io.to(r.driverId).emit('driver:cancelled', { id: r.id });
    }
    if (r.offeredTo) io.to(r.offeredTo).emit('driver:offer_expired', { id: r.id });
    r.status = 'cancelled';
    notifyRider(r);
  });

  socket.on('disconnect', () => {
    const d = drivers.get(socket.id);
    drivers.delete(socket.id);
    if (d) for (const r of rides.values()) {
      if (r.driverId === socket.id && ['accepted', 'arrived'].includes(r.status)) {
        r.driverId = null; r.asked.add(socket.id); offerRide(r); // re-match
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`RideGo running at http://localhost:${PORT}`));
